export function scrollProgress(scrollY,start,range){return Math.max(0,Math.min(1,(scrollY-start)/Math.max(1,range)));}
export function cinematicFrame(progress){
 const p=Math.max(0,Math.min(1,Number(progress)||0));const index=Math.min(3,Math.floor(p*4));
 const scenes=[
 {title:'STRIDE.',accent:'TU RITMO.<br>TUS REGLAS.',description:'Una marca. Todas tus formas de moverte.<br>Encuentra el par que cuenta tu historia.',name:'BIENVENIDO A STRIDE',tagline:'Un par para cada versión de ti.',word:'STRIDE.',id:'numeris-pink',image:'numeris-stage.svg',alt:'Numeris Pink Denim con cordones rosas',cta:'Descubrir Numeris'},
 {title:'DENIM.',accent:'PINK<br>ATTITUDE.',description:'Numeris Pink Denim.<br>Textura que se ve. Actitud que se siente.',name:'NUMERIS PINK DENIM',tagline:'01 / Denim oscuro · cordones rosa',word:'DENIM.',id:'numeris-pink',image:'numeris-stage.svg',alt:'Numeris Pink Denim, zapatilla de denim negro con cordones rosas y suela blanca',cta:'Descubrir Numeris'},
 {title:'BORN IN LA.',accent:'RAISED<br>ON STYLE.',description:'Nike SB Dunk Low × Born x Raised.<br>Un homenaje a las calles que nos hacen.',name:'NIKE SB × BORN X RAISED',tagline:'02 / Nuestro producto estrella',word:'BORN RAISED.',id:'born-raised',image:'born-stage.svg',alt:'Nike SB Dunk Low Born x Raised azul y blanco, con Swoosh iridiscente',cta:'Descubrir el Dunk'},
 {title:'DEJA',accent:'TU<br>HUELLA.',description:'Timberland Premium 6-Inch.<br>Un icono que camina contigo.',name:'TIMBERLAND PREMIUM',tagline:'03 / Tono trigo · carácter propio',word:'TIMBERLAND.',id:'timberland',image:'timberland.webp',alt:'Botas Timberland de color trigo con cuello negro y cordones',cta:'Descubrir Timberland'}];
 return {progress:p,index,local:p===1?1:p*4-index,...scenes[index]};
}
