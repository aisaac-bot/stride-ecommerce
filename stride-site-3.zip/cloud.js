import './supabase-sdk.js?v=20261114-24';
export const db=globalThis.supabase.createClient('https://jovyttwansefuuahyppp.supabase.co','sb_publishable_uFwpOJnvol-TQdvPBOgzCg_V--rmU42',{
 auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storageKey:'stride-auth-v1'}
});
export let recoveryUserId=null;
db.auth.onAuthStateChange((event,session)=>{if(event==='PASSWORD_RECOVERY'){recoveryUserId=session?.user?.id||null;try{sessionStorage.setItem('stride-recovery-user',recoveryUserId||'');}catch{}}});
export const products=[];
export let colors=[],categories=[],shipping=[];
const imageUrls=new Map();
export function message(error){
 const code=error?.code||'',raw=error?.message||'';
 if(code==='invalid_credentials')return 'Correo o contraseña incorrectos.';
 if(code==='email_not_confirmed')return 'Confirma tu correo con el enlace que recibiste antes de iniciar sesión.';
 if(code==='over_email_send_rate_limit'||code==='over_request_rate_limit')return 'Se realizaron muchos intentos. Espera unos minutos y vuelve a intentarlo.';
 if(code==='email_address_not_authorized'||raw.includes('Email address not authorized')||code==='unexpected_failure'&&/email/i.test(raw))return 'El envío de correos de registro aún no está disponible. Contacta con STRIDE.';
 if(code==='23505')return 'La información ya está registrada. Revisa tu correo o cédula.';
 if(code==='23514')return 'Revisa los datos: cédula de 10 dígitos, celular 09XXXXXXXX y dirección completa.';
 if(code==='same_password')return 'Elige una contraseña diferente a la actual.';
 if(code==='reauthentication_needed'||code==='reauthentication_not_valid')return 'Vuelve a iniciar sesión antes de cambiar tu contraseña.';
 if(code==='weak_password')return 'Utiliza una contraseña de al menos 8 caracteres.';
 if(code==='P0001')return raw;
 return 'No se pudo completar la operación. Revisa tu conexión e inténtalo de nuevo.';
}
async function result(query){const {data,error}=await query;if(error)throw error;return data;}
function remember(row){
 if(!row)return null;
 cachePublic('product:'+row.slug,row);
 const images=[...(row.images||[])].sort((a,b)=>a.sort_order-b.sort_order);
 for(const i of images)imageUrls.set(i.asset_key,{160:i.thumbnail_url,320:i.card_url,480:i.card_large_url,640:i.detail_url,1024:i.zoom_url});
 const p={dbId:row.id,id:row.slug,name:row.name,category:row.category,color:row.color,hex:row.hex,price:Number(row.price),oldPrice:row.compare_at_price==null?null:Number(row.compare_at_price),tagline:row.tagline,description:row.description,fit:row.fit_note,badge:row.badge,featured:row.featured_rank,image:images[0]?.asset_key||'',views:images.map(i=>({image:i.asset_key,label:i.view_label})),variants:row.variants||[],sizes:(row.variants||[]).map(v=>v.size_id)};
 const index=products.findIndex(v=>v.id===p.id);if(index<0)products.push(p);else products[index]=p;return p;
}
export const imageUrl=(file,width)=>imageUrls.get(file)?.[width]||`assets/fast-v2/${encodeURIComponent(file)}-${width}.webp`;
export async function catalog(filters,page=1,limit=12){
 const data=await result(db.rpc('stride_catalog',{p_category:filters.category||'all',p_search:filters.search||'',p_size:filters.size||null,p_color:filters.color||null,p_max_price:Number(filters.maxPrice??999999),p_sale:!!filters.saleOnly,p_favorites:!!filters.favoritesOnly,p_sort:filters.sort||'featured',p_page:page,p_limit:limit}));
 return {items:data.items.map(remember),total:data.total};
}
export async function getProduct(slug){
 const cached=cachedPublic('product:'+slug);if(cached)return remember(cached);
 const row=await result(db.from('products').select('id').eq('slug',slug).maybeSingle());
 return row?remember(await result(db.rpc('stride_product_data',{p_id:row.id}))):null;
}
export async function meta(){
 [categories,colors,shipping]=await Promise.all([
  result(db.from('categories').select('id,name,products(count)').order('sort_order')),
  result(db.from('colors').select('name,hex').order('name')),
  result(db.from('shipping_methods').select('*').order('fee'))
 ]);
}
export async function user(){const {data,error}=await db.auth.getSession();if(error)throw error;return data.session?.user||null;}
export async function profile(uid){
 const [p,a]=await Promise.all([result(db.from('profiles').select('*').eq('id',uid).single()),result(db.from('addresses').select('*').eq('user_id',uid).eq('is_default',true).maybeSingle())]);
 return {id:p.id,accountCode:'STR-'+String(p.account_number).padStart(6,'0'),name:p.first_name,lastName:p.last_name,email:p.email,cedula:p.cedula||'',phone:p.phone||'',street:a?.main_street||'',crossStreet:a?.secondary_street||'',house:a?.house_number||'',reference:a?.reference||''};
}
export async function favorites(){const rows=await result(db.from('favorites').select('products(slug)'));return rows.map(r=>r.products?.slug).filter(Boolean);}
export async function toggleFavorite(p,remove){await result(remove?db.from('favorites').delete().eq('product_id',p.dbId):db.from('favorites').upsert({product_id:p.dbId,user_id:(await user()).id},{onConflict:'user_id,product_id',ignoreDuplicates:true}));}
export async function cart(){
 const rows=await result(db.from('cart_items').select('variant_id,quantity,product_variants(size_id,products(slug))').order('created_at'));
 const slugs=[...new Set(rows.map(r=>r.product_variants?.products?.slug).filter(Boolean))];
 await Promise.all(slugs.filter(s=>!products.some(p=>p.id===s)).map(getProduct));
 return rows.map(r=>({variantId:r.variant_id,id:r.product_variants?.products?.slug,size:r.product_variants?.size_id,quantity:r.quantity})).filter(r=>r.id);
}
export async function changeCart(id,size,quantity,add=false){const p=products.find(v=>v.id===id)||await getProduct(id),v=p?.variants.find(v=>v.size_id===Number(size));if(!v)throw {code:'P0001',message:'Esta talla ya no está disponible.'};await result(db.rpc('stride_cart_change',{p_variant:v.id,p_quantity:quantity,p_add:add}));return cart();}
export async function loadDraft(uid){const d=await result(db.from('checkout_drafts').select('*').eq('user_id',uid).maybeSingle());return d?{recipient:d.recipient,phone:d.phone,street:d.main_street,crossStreet:d.secondary_street,house:d.house_number,reference:d.reference,delivery:d.shipping_method_code||'standard',payment:'cash'}:{};}
export async function saveDraft(uid,d){await result(db.from('checkout_drafts').upsert({user_id:uid,recipient:d.recipient||'',phone:d.phone||'',main_street:d.street||'',secondary_street:d.crossStreet||'',house_number:d.house||'',reference:d.reference||'',shipping_method_code:d.delivery||'standard',payment_method_code:'cash'},{onConflict:'user_id'}));}
export async function saveProfile(data){await result(db.rpc('stride_save_profile',{p_data:data}));}
export async function checkout(key,delivery){return result(db.rpc('stride_checkout',{p_key:key,p_delivery:{...delivery,payment:'cash',city:'Quito'}}));}
export async function order(id){
 let query=db.from('orders').select('*,order_items(*),payments(status)');query=id?query.eq('id',id):query.order('created_at',{ascending:false}).limit(1);
 const o=await result(query.maybeSingle());if(!o)return null;
 return {raw:o,dbId:o.id,emailSentAt:o.email_sent_at,email:o.customer_email,pickupCode:o.pickup_code,id:'STR-'+String(o.order_number).padStart(6,'0'),subtotal:Number(o.subtotal),shipping:Number(o.shipping_amount),total:Number(o.total),status:o.status,items:o.order_items.map(i=>({name:i.product_name,size:i.size_eu,quantity:i.quantity,price:Number(i.unit_price)})),delivery:{recipient:o.recipient,phone:o.phone,street:o.main_street,crossStreet:o.secondary_street,house:o.house_number,reference:o.reference,delivery:o.shipping_method_code}};
}
export async function orders(){return result(db.from('orders').select('id,order_number,status,total,created_at').order('created_at',{ascending:false}).limit(20));}

export async function sendOrderEmail(id){
 const {data,error}=await db.functions.invoke('send-order-email',{body:{order_id:id}});
 if(error)throw error;return data;
}

// Short-lived public product data survives navigation between HTML pages.
const prefetchRequests=new Map();
function cachedPublic(key){
 try{const entry=JSON.parse(sessionStorage.getItem('stride-public-prefetch')||'{}')[key];return entry&&Date.now()-entry.time<60000?entry.data:null;}catch{return null;}
}
function cachePublic(key,data){
 try{let entries=JSON.parse(sessionStorage.getItem('stride-public-prefetch')||'{}');entries[key]={time:entries[key]&&Date.now()-entries[key].time<60000?entries[key].time:Date.now(),data};entries=Object.fromEntries(Object.entries(entries).filter(([,v])=>Date.now()-v.time<60000).sort((a,b)=>b[1].time-a[1].time).slice(0,8));sessionStorage.setItem('stride-public-prefetch',JSON.stringify(entries));}catch{}
}
export function recommendations(category){
 const key='related:'+category,hit=cachedPublic(key);
 if(hit)return Promise.resolve(hit.map(remember));
 if(prefetchRequests.has(key))return prefetchRequests.get(key);
 const request=catalog({category},1,5).then(({items})=>{const rows=items.map(p=>p.id);cachePublic(key,rows.map(id=>cachedPublic('product:'+id)).filter(Boolean));return items;}).finally(()=>prefetchRequests.delete(key));
 prefetchRequests.set(key,request);return request;
}
export async function prefetchProduct(slug){
 const key='product:'+slug;if(prefetchRequests.has(key))return prefetchRequests.get(key);
 const request=getProduct(slug).then(async p=>{if(p)await recommendations(p.category);}).finally(()=>prefetchRequests.delete(key));prefetchRequests.set(key,request);return request;
}
