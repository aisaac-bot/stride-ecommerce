// Shared by the browser and the server: small PDFs without external fonts or images.
export const PICKUP_ADDRESS='Av. de los Shyris y Portugal, sector La Carolina, Quito.';
export const PICKUP_HOURS='Lunes a viernes: 09:00 a 18:00. Sábados: 10:00 a 14:00. Domingos y feriados: cerrado.';
export const orderNumber=o=>'STR-'+String(o.order_number).padStart(6,'0');
export const orderStatus=o=>({pending:'Pendiente',confirmed:'Confirmado',preparing:'En preparación',shipped:'Enviado',delivered:'Entregado',cancelled:'Cancelado'})[o.status]||'Pendiente';
const cash=n=>'$'+Number(n).toFixed(2);
const clean=s=>String(s??'').replace(/[\r\n\t]+/g,' ').replace(/[–—]/g,'-').replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/[^\x20-\xFF]/g,'?');
const literal=s=>clean(s).replace(/([\\()])/g,'\\$1');
export function orderPdf(o){
 const pages=[];let lines=[],y=780;
 const put=(text,size=11,bold=false,color='0.1 0.1 0.1')=>{if(y<65){pages.push(lines.join('\n'));lines=[];y=780;}lines.push(`BT /${bold?'F2':'F1'} ${size} Tf ${color} rg 1 0 0 1 48 ${y} Tm (${literal(text)}) Tj ET`);y-=size+8;};
 const paragraph=(text,size=11,bold=false)=>{let line='';const limit=Math.floor(490/(size*.56));for(const word of clean(text).split(' ')){if(line.length+word.length+1>limit){put(line,size,bold);line='';}for(let i=0;i<word.length;i+=limit){const part=word.slice(i,i+limit);if(i+limit<word.length){if(line){put(line,size,bold);line='';}put(part,size,bold);}else line+=(line?' ':'')+part;}}if(line)put(line,size,bold);};
 const gap=()=>{y-=12;};
 put('STRIDE',26,true);put(o.shipping_method_code==='pickup'?'ORDEN DE RETIRO':'ORDEN DE PEDIDO',15,true);gap();
 put(orderNumber(o),18,true);paragraph('Fecha: '+new Date(o.created_at).toLocaleDateString('es-EC',{timeZone:'America/Guayaquil'}));
 paragraph('Cliente: '+o.recipient);paragraph('Estado del pedido: '+orderStatus(o));
 if(o.shipping_method_code==='pickup'){paragraph('Código de retiro: '+o.pickup_code,13,true);if(['cancelled','delivered'].includes(o.status))paragraph('Esta orden no permite un nuevo retiro.',12,true);}
 paragraph(o.payments?.some(p=>p.status==='paid')?'Pago registrado':'Pago pendiente - '+(o.shipping_method_code==='pickup'?'Paga al retirar':'Contra entrega'),12,true);
 gap();put('PRODUCTOS',13,true);
 for(const item of o.order_items||[]){paragraph(item.product_name,12,true);paragraph(`Talla EU ${item.size_eu} | Cantidad: ${item.quantity} | Precio: ${cash(item.unit_price)} | Importe: ${cash(Number(item.unit_price)*item.quantity)}`);gap();}
 paragraph('Productos: '+cash(o.subtotal));paragraph('Envío: '+cash(o.shipping_amount));paragraph('TOTAL USD: '+cash(o.total),16,true);gap();
 if(o.shipping_method_code==='pickup'){paragraph('RETIRO EN TIENDA',13,true);paragraph(PICKUP_ADDRESS);paragraph(PICKUP_HOURS);paragraph('Presenta esta orden desde tu celular o impresa dentro del horario de atención. La tienda verificará el pedido y registrará su entrega.');}
 else {paragraph('ENTREGA EN QUITO',13,true);paragraph([o.main_street,o.secondary_street,'Casa: '+o.house_number,o.reference].filter(Boolean).join(' · '));}
 gap();paragraph('Contacto: 0984089185 | stride@gmail.com');paragraph('Conserva tu código de retiro en privado. Esta orden no es una factura ni un comprobante de pago.',10);
 pages.push(lines.join('\n'));
 const objs=['<< /Type /Catalog /Pages 2 0 R >>','', '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'];const kids=[];
 pages.forEach((content,i)=>{const page=objs.length+1,stream=page+1;kids.push(page+' 0 R');const footer=`\nBT /F1 9 Tf 0.4 0.4 0.4 rg 1 0 0 1 48 32 Tm (${orderNumber(o)} - ${i+1} / ${pages.length}) Tj ET`;content+=footer;objs.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${stream} 0 R >>`,`<< /Length ${content.length} >>\nstream\n${content}\nendstream`);});
 objs[1]=`<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${pages.length} >>`;let pdf='%PDF-1.4\n',offsets=[0];objs.forEach((o,i)=>{offsets.push(pdf.length);pdf+=`${i+1} 0 obj\n${o}\nendobj\n`;});const xref=pdf.length;pdf+=`xref\n0 ${objs.length+1}\n0000000000 65535 f \n`+offsets.slice(1).map(n=>String(n).padStart(10,'0')+' 00000 n \n').join('')+`trailer\n<< /Size ${objs.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
 return Uint8Array.from(pdf,c=>c.charCodeAt(0));
}
