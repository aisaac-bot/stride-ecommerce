import * as cloud from './cloud.js?v=20261102-20';
const {products}=cloud;
const defaults=()=>({category:'all',search:'',size:null,color:null,maxPrice:400,saleOnly:false,favoritesOnly:false,sort:'featured'});
const cartTotals=items=>({quantity:items.reduce((n,v)=>n+v.quantity,0),total:items.reduce((n,v)=>n+(products.find(p=>p.id===v.id)?.price||0)*v.quantity,0)});
import {cinematicFrame} from './cinema.js?v=20261102-17';

const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const money=n=>`$${n.toFixed(2)}`;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const drawings={
 'heart':'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
 'bag':'<path d="M5 7h14l1 14H4L5 7Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/>',
 'menu':'<path d="M4 6h16M4 12h16M4 18h16"/>',
 'close':'<path d="m6 6 12 12M18 6 6 18"/>',
 'search':'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
 'arrow-right':'<path d="M4 12h16m-6-6 6 6-6 6"/>',
 'arrow-up-right':'<path d="M6 18 18 6M6 6h12v12"/>',
 'arrow-down':'<path d="M12 4v16m-6-6 6 6 6-6"/>',
 'arrow-up':'<path d="M12 20V4m-6 6 6-6 6 6"/>',
 'sliders':'<path d="M4 6h5m4 0h7M4 12h9m4 0h3M4 18h3m4 0h9"/><circle cx="11" cy="6" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="9" cy="18" r="2"/>',
 'ruler':'<path d="m3 16 13-13 5 5L8 21 3 16Z"/><path d="m13 6 3 3M9 10l2 2m-6 2 3 3"/>',
 'spark':'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z"/>',
 'check':'<path d="m5 12 4 4L19 6"/>',
 'zoom':'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5M10.5 7v7M7 10.5h7"/>'
};
const icon=name=>`<svg viewBox="0 0 24 24" aria-hidden="true">${drawings[name]||drawings['arrow-right']}</svg>`;
function hydrateIcons(root=document){root.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=icon(el.dataset.icon);});}
function read(key,fallback){try{return JSON.parse(sessionStorage.getItem(key))??fallback;}catch{return fallback;}}
function write(key,value){try{sessionStorage.setItem(key,JSON.stringify(value));}catch{}}

const page=document.body.dataset.page;
let activeProfile=null,cart=[],favorites=[],appReady=false,catalogSequence=0,searchTimer,draftTimer,draftWrites=Promise.resolve();
let filters=defaults(),catalogPage=1,lastCatalogQuery='',currentProduct=null,selectedSize=null,detailQuantity=1,toastTimer,lastRemovedItem=null;
const pageSize=12,dialogs=$$('dialog');filters.favoritesOnly=page==='favoritos';
const on=(selector,event,fn)=>$(selector)?.addEventListener(event,fn);
function go(url){location.href=url;}
function requireAccount(action){if(activeProfile)return true;write('stride-pending',action||null);write('stride-return',location.pathname.split('/').pop()+location.search);go('login.html');return false;}
function showDialog(d){if(d&&!d.open)d.showModal();}
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),6000);}
function productError(message){$('#product-alert-message').textContent=message;showDialog($('#product-alert'));$('#product-alert-ok').focus();}
function updateCartCount(){const total=cartTotals(cart);$('#cart-count').textContent=total.quantity;$('#cart-count').hidden=!total.quantity;if($('#cart-title-count'))$('#cart-title-count').textContent='('+total.quantity+')';}

function ratingMarkup(p){return "";}
function badge(p){return p.badge?`<span class="product-badge${p.oldPrice?' sale':''}">${esc(p.badge)}</span>`:'';}

const optimizedImage=cloud.imageUrl;
function productCard(p,index=0){return `<article class="product-card" data-product="${p.id}">
  <a class="product-image-wrap" href="producto.html?id=${p.id}" aria-label="Ver detalle de ${esc(p.name)}" data-placeholder="Imagen de ${esc(p.name)}">${badge(p)}<img class="product-image ${p.id==='born-raised'?'born-image':''}" src="${optimizedImage(p.image,320)}" srcset="${optimizedImage(p.image,320)} 320w, ${optimizedImage(p.image,480)} 480w" sizes="(max-width:700px) 50vw, (max-width:1000px) 33vw, 25vw" decoding="async" alt="${esc(p.name)}, ${esc(p.category.toLowerCase())} de color ${esc(p.color.toLowerCase())}" width="1024" height="1024" loading="${index<6&&!location.hash.startsWith('#producto/')?'eager':'lazy'}"><span class="product-view">Explorar el par ${icon('arrow-up-right')}</span></a>
  <button class="product-favorite" data-favorite="${p.id}" aria-label="${favorites.includes(p.id)?'Quitar de':'Añadir a'} favoritos: ${esc(p.name)}" aria-pressed="${favorites.includes(p.id)}">${icon('heart')}</button>
  <div class="product-info"><div class="product-type"><span>${esc(p.category)}</span><span class="product-color"><i style="background:${esc(p.hex)}" aria-hidden="true"></i>${esc(p.color)}</span></div><div class="product-name-price"><h3><a href="producto.html?id=${p.id}">${esc(p.name)}</a></h3><div class="product-price">${p.oldPrice?`<del>$${p.oldPrice}</del>`:''}$${p.price}</div></div>${ratingMarkup(p)}<div class="product-sizes"><span>EU</span>${p.sizes.map(s=>`<span>${s}</span>`).join('')}</div></div>
 </article>`;}

async function renderCatalog(){
 const request=++catalogSequence;
 const query=JSON.stringify(filters);if(query!==lastCatalogQuery){catalogPage=1;lastCatalogQuery=query;}
 syncFilters();$('#product-grid').setAttribute('aria-busy','true');$('#result-count').textContent='Cargando productos…';$('#empty-state').hidden=true;
 try{
 const {items:found,total}=await cloud.catalog({...filters},catalogPage,pageSize);if(request!==catalogSequence)return;
 const pages=Math.max(1,Math.ceil(total/pageSize));if(catalogPage>pages){catalogPage=pages;return renderCatalog();}
 $('#product-grid').innerHTML=found.map(productCard).join('');
 $('#catalog-pagination').hidden=pages<=1;
 $('#catalog-pagination').innerHTML=`<button type="button" data-page="${catalogPage-1}" ${catalogPage===1?'disabled':''}>← Anterior</button><span role="status">Página ${catalogPage} de ${pages}</span><button type="button" data-page="${catalogPage+1}" ${catalogPage===pages?'disabled':''}>Siguiente →</button>`;
 $('#result-count').textContent=`${total} ${total===1?'producto':'productos'}${filters.favoritesOnly?' en favoritos':''}`;
 $('#empty-state').hidden=found.length>0;
 const noFavorites=filters.favoritesOnly&&favorites.length===0;
 $('#empty-state h3').textContent=noFavorites?'No tienes artículos añadidos a favoritos':filters.favoritesOnly?'No hay favoritos que coincidan con tu búsqueda':'No encontramos ese par';
 $('#empty-state p').textContent=noFavorites?'Explora la colección y pulsa el corazón de los productos que te gusten.':'Prueba otra talla, color o precio para encontrar tu par.';
 $('#empty-state [data-icon]').innerHTML=icon(noFavorites?'heart':'search');
 $('#empty-clear').innerHTML=(noFavorites?'Explorar colección':'Restablecer búsqueda')+' '+icon('arrow-right');
 $('#favorites-clear').hidden=!filters.favoritesOnly;
 updateFavoriteUI();
 }catch(error){if(request!==catalogSequence)return;$('#result-count').textContent='No se pudo cargar la colección.';$('#product-grid').innerHTML='<p role="alert">'+esc(cloud.message(error))+' <button class="text-button" id="catalog-retry">Reintentar</button></p>';$('#catalog-pagination').hidden=true;}finally{if(request===catalogSequence)$('#product-grid').removeAttribute('aria-busy');}
}
function syncFilters(){
 $$('[data-category]').forEach(b=>{const active=b.dataset.category===filters.category;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
 $$('[data-filter-size]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.filterSize)===filters.size)));
 $$('[data-filter-color]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.filterColor===filters.color)));
 $('#search').value=filters.search;$('#max-price').value=filters.maxPrice;$('#price-value').textContent=`$${filters.maxPrice}`;$('#sale-only').checked=filters.saleOnly;$('#sort').value=filters.sort;
 const chips=[];
 if(filters.category!=='all')chips.push(['category',filters.category]);
 if(filters.search)chips.push(['search',`“${filters.search}”`]);
 if(filters.size)chips.push(['size',`Talla ${filters.size}`]);
 if(filters.color)chips.push(['color',filters.color]);
 if(filters.maxPrice<defaults().maxPrice)chips.push(['maxPrice',`Hasta $${filters.maxPrice}`]);
 if(filters.saleOnly)chips.push(['saleOnly','Ofertas']);
 if(filters.favoritesOnly)chips.push(['favoritesOnly','Favoritos']);
 $('#active-filters').innerHTML=chips.map(([key,label])=>`<button class="filter-chip" data-remove-filter="${key}" aria-label="Quitar filtro: ${esc(label)}">${esc(label)}${icon('close')}</button>`).join('');
 $('#filter-count').textContent=chips.length?String(chips.length):'';
}
function resetFilters(){filters=defaults();filters.favoritesOnly=page==='favoritos';renderCatalog();}
function updateFavoriteUI(){
 $('#favorite-count').textContent=favorites.length;$('#favorite-count').hidden=favorites.length===0;
 $('#favorites-toggle').setAttribute('aria-pressed',String(filters.favoritesOnly));
 $('#favorites-toggle').setAttribute('aria-label',filters.favoritesOnly?'Ver toda la colección':'Ver favoritos');
 $$('[data-favorite]').forEach(b=>{
  const active=favorites.includes(b.dataset.favorite);const p=products.find(p=>p.id===b.dataset.favorite);
  b.setAttribute('aria-pressed',String(active));b.setAttribute('aria-label',`${active?'Quitar de':'Añadir a'} favoritos: ${esc(p.name)}`);
  const label=b.querySelector('[data-favorite-label]');if(label)label.textContent=active?'Guardado en tus favoritos':'Guardar en favoritos';
 });
}
let favoriteBusy=false;
async function toggleFavorite(id){if(!requireAccount({type:'favorite',id})||favoriteBusy)return;favoriteBusy=true;try{const remove=favorites.includes(id),p=products.find(p=>p.id===id)||await cloud.getProduct(id);await cloud.toggleFavorite(p,remove);favorites=await cloud.favorites();if($('#product-grid'))await renderCatalog();else updateFavoriteUI();toast(remove?'Eliminado de tus favoritos.':'Guardado en tus favoritos.');}catch(error){toast(cloud.message(error));}finally{favoriteBusy=false;}}
function productViews(p){return p.views;}
function renderProduct(p){
 currentProduct=p;selectedSize=null;detailQuantity=1;
 $('#product-detail').innerHTML=`<div class="detail-layout"><div class="detail-image-panel" id="detail-image-panel">${badge(p)}<img class="${p.id==='born-raised'?'born-image':''}" src="${optimizedImage(p.image,640)}" fetchpriority="high" decoding="async" alt="${esc(p.name)} en color ${esc(p.color.toLowerCase())}" width="1024" height="1024"><span class="detail-image-caption">STRIDE SELECTION / ${esc(p.category.toUpperCase())}</span><button class="zoom-button" id="image-zoom" aria-label="Ampliar imagen" aria-pressed="false">${icon('zoom')}</button></div><div class="detail-copy"><p class="detail-category">COLECCIÓN 01 / ${esc(p.category.toUpperCase())}</p><h1 id="detail-title" tabindex="-1">${esc(p.name)}</h1>${ratingMarkup(p)}<p class="detail-tagline">${esc(p.tagline)}</p><div class="detail-price">${money(p.price)}${p.oldPrice?`<del>${money(p.oldPrice)}</del>`:''}<small>USD</small></div><p class="detail-description">${esc(p.description)}</p><p class="detail-color"><i style="background:${esc(p.hex)}" aria-hidden="true"></i><strong>Color:</strong> ${esc(p.color)}</p><div class="detail-size-head"><span>Selecciona tu talla · EU</span><button class="text-button" id="detail-size-guide">Guía de tallas</button></div><div class="detail-sizes" role="group" aria-label="Talla del producto">${Array.from({length:9},(_,i)=>i+36).map(s=>`<button data-detail-size="${s}" aria-pressed="false" ${p.sizes.includes(s)?'':`disabled aria-label="Talla ${s}, no disponible"`}>${s}</button>`).join('')}</div><p class="size-error" id="size-error" role="alert"></p><div class="detail-buy"><div class="quantity-control" aria-label="Cantidad de pares"><button id="detail-minus" aria-label="Reducir cantidad" disabled>−</button><span id="detail-quantity" aria-live="polite">1</span><button id="detail-plus" aria-label="Aumentar cantidad">+</button></div><button class="button button-red" id="add-cart">Añadir al carrito ${icon('bag')}</button></div><button class="detail-favorite" data-favorite="${p.id}" aria-pressed="${favorites.includes(p.id)}">${icon('heart')}<span data-favorite-label>${favorites.includes(p.id)?'Guardado en tus favoritos':'Guardar en favoritos'}</span></button><p class="fit-note">${esc(p.fit)}</p></div></div>`;
 {
  const views=productViews(p);
  const mainImage=$('#detail-image-panel img');mainImage.dataset.viewImage=p.image;
  const panel=$('#detail-image-panel'),gallery=document.createElement('div');gallery.className='detail-gallery';panel.before(gallery);gallery.append(panel);
  gallery.insertAdjacentHTML('beforeend',`<div class="gallery-thumbnails" role="group" aria-label="Vistas de ${esc(p.name)}">${views.map((view,i)=>`<button type="button" data-product-view="${i}" aria-pressed="${i===0}" aria-label="Ver vista ${esc(view.label.toLowerCase())}"><img src="${optimizedImage(view.image,160)}" width="160" height="160" alt="Miniatura ${esc(view.label.toLowerCase())}" class="${i===0&&p.id==='born-raised'?'gallery-original':''}" loading="lazy" decoding="async"><span>${esc(view.label)}</span></button>`).join('')}</div>${p.id==='born-raised'?'':''}`);
 }
 $('#product-category-label').textContent=p.category;
 const related=products.filter(item=>item.id!==p.id).sort((a,b)=>Number(b.category===p.category)-Number(a.category===p.category)||Math.abs(a.price-p.price)-Math.abs(b.price-p.price)).slice(0,4);
 $('#related-grid').innerHTML=related.map(productCard).join('');
 updateFavoriteUI();
}
function renderCart(){
 updateCartCount();
 const notice=lastRemovedItem?`<div class="cart-notice" role="status">${products.find(p=>p.id===lastRemovedItem.id).name} eliminado.</div>`:'';
 if(!cart.length){$('#cart-body').innerHTML=notice+`<div class="cart-empty"><span>${icon('bag')}</span><h3>Tu próximo par te espera</h3><p>Explora la colección y añade tus favoritos.</p><button class="button button-black" id="cart-explore">Explorar colección ${icon('arrow-right')}</button></div>`;$('#cart-footer').innerHTML='';return;}
 $('#cart-body').innerHTML=notice+cart.map((v,i)=>{const p=products.find(p=>p.id===v.id);return `<article class="cart-item"><a class="cart-item-image" href="producto.html?id=${p.id}" data-cart-product><img src="${optimizedImage(p.image,160)}" decoding="async" alt="${esc(p.name)}" width="100" height="100"></a><div><div class="cart-item-head"><h3>${esc(p.name)}</h3><button data-cart-action="remove" data-index="${i}" aria-label="Eliminar ${esc(p.name)}, talla ${v.size}">${icon('close')}</button></div><p>${esc(p.color)} · Talla ${v.size} EU</p><div class="cart-item-bottom"><div class="quantity-control"><button data-cart-action="minus" data-index="${i}" aria-label="Reducir cantidad de ${esc(p.name)}" ${v.quantity<=1?'disabled':''}>−</button><span>${v.quantity}</span><button data-cart-action="plus" data-index="${i}" aria-label="Aumentar cantidad de ${esc(p.name)}" ${v.quantity>=10?'disabled':''}>+</button></div><strong>${money(p.price*v.quantity)}</strong></div></div></article>`;}).join('');
 const totals=cartTotals(cart);
 $('#cart-footer').innerHTML=`<div class="cart-total"><span>Total estimado</span><strong>${money(totals.total)}</strong></div><p class="cart-disclaimer">Precios en dólares estadounidenses.</p><button class="button button-red" id="simulate-order">Continuar compra ${icon('arrow-right')}</button><p class="cart-footnote">Envíos solo a Quito. El costo se calcula en el siguiente paso.</p>`;
}
let checkoutStep=1;
const shippingPrices={};
const deliveryNames={standard:'Quito · a domicilio estándar',express:'Quito · a domicilio exprés',pickup:'Retiro en Quito'};
function checkoutData(){return {...Object.fromEntries(new FormData($('#checkout-form')).entries()),city:'Quito',phone:$('#contact-phone').value.replace(/[\s-]/g,'')};}
function orderAmounts(){const subtotal=cartTotals(cart).total;const shipping=shippingPrices[$('#delivery-method').value]??5;return {subtotal,shipping,total:subtotal+shipping};}
function amountMarkup(){const t=orderAmounts();return `<div><span>Productos</span><strong>${money(t.subtotal)}</strong></div><div><span>Envío</span><strong>${t.shipping?money(t.shipping):'Gratis'}</strong></div><div class="grand-total"><span>Total · USD</span><strong>${money(t.total)}</strong></div>`;}
function orderLines(){return cart.map(v=>{const p=products.find(p=>p.id===v.id);return `<li><span>${esc(p.name)}<small>Talla EU ${v.size} · ${v.quantity} × ${money(p.price)}</small></span><strong>${money(p.price*v.quantity)}</strong></li>`;}).join('');}
function deliveryMarkup(data){return `<p><strong>${deliveryNames[data.delivery]}</strong><br>${esc(data.recipient||'')}<br>${esc(data.phone||'')}${data.delivery==='pickup'?'<br>Retiro en tienda: Av. de los Shyris y Portugal, sector La Carolina, Quito.<br>Espera la confirmación antes de acudir.':`<br>Quito · ${esc(data.street||'')} y ${esc(data.crossStreet||'')}<br>Casa: ${esc(data.house||'')}<br>${esc(data.reference||'')}`}</p><p>Pago: ${data.delivery==='pickup'?'Al retirar':'Contra entrega'}</p>`;}
function updateCheckout(){
 const data=checkoutData(),pickup=data.delivery==='pickup';
 $('#address-fields').disabled=pickup;$('#address-fields').hidden=pickup;$('#pickup-note').hidden=!pickup;
 $('#delivery-estimate').textContent='El pedido quedará pendiente de confirmación por STRIDE.';
 $('#contact-phone').required=true;$('#cash-note').hidden=false;
 $('#cash-note').textContent=pickup?'Pagarás el total al retirar el pedido en tienda.':'Pagarás el total al recibir tu pedido. Sin recargo.';
 $('#checkout-totals').innerHTML=amountMarkup();$('#checkout-items').innerHTML=orderLines();
 $('#checkout-review').innerHTML=`<ul class="order-lines">${orderLines()}</ul>${deliveryMarkup(data)}`;
}
function setCheckoutStep(step){
 checkoutStep=step;$$('[data-checkout-step]').forEach(el=>el.hidden=Number(el.dataset.checkoutStep)!==step);
 $$('[data-step-label]').forEach(el=>{if(Number(el.dataset.stepLabel)===step)el.setAttribute('aria-current','step');else el.removeAttribute('aria-current');});
 $('#checkout-back').textContent=step===1?'Volver al carrito':'← Atrás';$('#checkout-next').textContent=step===1?'Continuar al pago →':step===2?'Revisar pedido →':'Confirmar pedido';$('#checkout-error').textContent='';updateCheckout();
 $(`[data-checkout-step="${step}"] h3`).focus();
}

function finishSession(){const destination=read('stride-return','perfil.html');sessionStorage.removeItem('stride-return');go(/^(index|catalogo|favoritos|producto|carrito|checkout|perfil)\.html(?:\?[^#]*)?$/.test(destination)?destination:'perfil.html');}
async function logout(){try{const {error}=await cloud.db.auth.signOut();if(error)throw error;sessionStorage.removeItem('stride-pending');go('login.html');}catch(error){toast(cloud.message(error));}}
async function init(){
 hydrateIcons();
 const loading=document.createElement('p');loading.id='connection-status';loading.className='connection-status';loading.setAttribute('role','status');loading.textContent='Cargando tienda…';document.querySelector('main').prepend(loading);
 try{
 const u=await cloud.user();
 if(u){[activeProfile,cart,favorites]=await Promise.all([cloud.profile(u.id),cloud.cart(),cloud.favorites()]);}
 sessionStorage.removeItem('stride-session-accounts');sessionStorage.removeItem('stride-profile');
 updateCartCount();updateFavoriteUI();
 $$('[data-account-open]').forEach(a=>{a.textContent=activeProfile?'Mi perfil':'Iniciar sesión';a.href=activeProfile?'perfil.html':'login.html';a.setAttribute('aria-label',a.textContent);});
 $$('.nav-link').forEach(a=>{const current=a.getAttribute('href')===page+'.html';a.classList.toggle('active',current);if(current)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
 if(['favoritos','carrito','checkout','perfil','confirmacion'].includes(page)&&!requireAccount())return;
 if(activeProfile&&['login','registro'].includes(page)){finishSession();return;}
 appReady=true;
 const pending=read('stride-pending',null);if(activeProfile&&pending){sessionStorage.removeItem('stride-pending');try{const p=await cloud.getProduct(pending.id);if(p&&pending.type==='favorite'&&!favorites.includes(p.id)){await cloud.toggleFavorite(p,false);favorites=await cloud.favorites();}if(p&&pending.type==='cart')cart=await cloud.changeCart(p.id,pending.size,pending.quantity,true);}catch(e){toast(cloud.message(e));}}
 if($('#product-grid')){
  await cloud.meta();
  $('.category-tabs').innerHTML='<button data-category="all" class="category active" aria-pressed="true">Todos <span>'+cloud.categories.reduce((n,c)=>n+(c.products?.[0]?.count||0),0)+'</span></button>'+cloud.categories.map(c=>'<button data-category="'+esc(c.name)+'" class="category" aria-pressed="false">'+esc(c.name)+' <span>'+(c.products?.[0]?.count||0)+'</span></button>').join('');
  $('#size-filter').innerHTML=Array.from({length:9},(_,i)=>i+36).map(n=>`<button data-filter-size="${n}" aria-pressed="false" aria-label="Filtrar por talla ${n}">${n}</button>`).join('');
  $('#color-filter').innerHTML=cloud.colors.map(c=>`<button data-filter-color="${esc(c.name)}" aria-pressed="false"><span class="swatch" style="background:${esc(c.hex)}"></span>${esc(c.name)}</button>`).join('');
  await renderCatalog();
 }
 if(page==='producto'){
  const product=await cloud.getProduct(new URLSearchParams(location.search).get('id')||'');
  if(product){await cloud.catalog({category:product.category},1,5);renderProduct(product);document.title=product.name+' — STRIDE';}
  else{$('#product-detail').innerHTML='<h1>Producto no encontrado</h1><a href="catalogo.html">Explorar catálogo</a>';$('.related-products').hidden=true;}
 }
 if(page==='carrito')renderCart();
 if(page==='checkout'){
  if(!cart.length){go('carrito.html');return;}
  await cloud.meta();for(const method of cloud.shipping)shippingPrices[method.code]=Number(method.fee);
  $('#delivery-method').innerHTML=cloud.shipping.map(m=>`<option value="${esc(m.code)}">${esc(m.name)} · ${money(Number(m.fee))}</option>`).join('');
  const saved=read('stride-draft-'+activeProfile.id,null)||await cloud.loadDraft(activeProfile.id),values={recipient:activeProfile.name+' '+activeProfile.lastName,phone:activeProfile.phone,street:activeProfile.street,crossStreet:activeProfile.crossStreet,house:activeProfile.house,reference:activeProfile.reference,...saved};
  for(const [key,value] of Object.entries(values)){const f=$('#checkout-form').elements.namedItem(key);if(f&&value!=null)f.value=value;}
  if(!$('#delivery-method').value)$('#delivery-method').value=cloud.shipping[0]?.code||'';setCheckoutStep(1);
 }
 if(page==='confirmacion'){
  const id=new URLSearchParams(location.search).get('id');const order=await cloud.order(id&&/^[0-9a-f-]{36}$/i.test(id)?id:null);
  if(!order){$('#order-summary').textContent='No tienes un pedido reciente.';}else{$('#order-summary').innerHTML=`<p>Pedido <strong>${esc(order.id)}</strong></p><ul class="order-lines">${order.items.map(v=>`<li>${esc(v.name)} · EU ${v.size} · ${v.quantity} × ${money(v.price)}</li>`).join('')}</ul><p>Productos: ${money(order.subtotal)}</p><p>Envío: ${money(order.shipping)}</p><p><strong>Total: ${money(order.total)}</strong></p>${deliveryMarkup(order.delivery)}<p>Pago pendiente · Contra entrega.</p>`;$('#delivery-status').textContent='Pedido registrado · Pendiente de confirmación';}
 }
 if(page==='perfil'){
  for(const [key,value] of Object.entries(activeProfile)){const f=$('#profile-form').elements.namedItem(key);if(f)f.value=value;}
  const orders=await cloud.orders();$('#profile-orders').innerHTML=orders.length?orders.map(o=>`<li><a href="confirmacion.html?id=${o.id}">Pedido STR-${String(o.order_number).padStart(6,'0')}</a> · ${money(Number(o.total))} · ${esc(({pending:'Pendiente',confirmed:'Confirmado',preparing:'En preparación',shipped:'Enviado',delivered:'Entregado',cancelled:'Cancelado'})[o.status]||o.status)}</li>`).join(''):'<li>Todavía no tienes pedidos.</li>';
 }
 updateCartCount();updateFavoriteUI();loading.remove();
 }catch(error){appReady=false;loading.setAttribute('role','alert');loading.innerHTML=esc(cloud.message(error))+' <button type="button" class="text-button" id="connection-retry">Reintentar</button>';}
}
on('#menu-toggle','click',()=>{const open=$('#mobile-menu').hidden;$('#mobile-menu').hidden=!open;$('#menu-toggle').setAttribute('aria-expanded',String(open));});
on('#filter-toggle','click',()=>{const open=$('#filter-toggle').getAttribute('aria-expanded')!=='true';$('#filter-toggle').setAttribute('aria-expanded',String(open));$('#filter-panel').classList.toggle('is-open',open);});
for(const [sel,key,event] of [['#search','search','input'],['#sort','sort','change'],['#max-price','maxPrice','input'],['#sale-only','saleOnly','change']])on(sel,event,e=>{filters[key]=key==='saleOnly'?e.target.checked:e.target.value;clearTimeout(searchTimer);searchTimer=setTimeout(renderCatalog,event==='input'?250:0);});
on('#clear-filters','click',resetFilters);on('#favorites-clear','click',()=>go('catalogo.html'));on('#empty-clear','click',()=>{if(page==='favoritos'&&!favorites.length)go('catalogo.html');else resetFilters();});
function rememberDraft(){if(!activeProfile)return;write('stride-draft-'+activeProfile.id,checkoutData());clearTimeout(draftTimer);draftTimer=setTimeout(()=>flushDraft().catch(error=>toast(cloud.message(error))),500);}
async function flushDraft(){clearTimeout(draftTimer);if(!activeProfile||!$('#checkout-form'))return;const d=checkoutData(),uid=activeProfile.id;write('stride-draft-'+uid,d);draftWrites=draftWrites.catch(()=>{}).then(()=>cloud.saveDraft(uid,d));await draftWrites;if(JSON.stringify(read('stride-draft-'+uid,null))===JSON.stringify(d))sessionStorage.removeItem('stride-draft-'+uid);}
on('#checkout-form','input',rememberDraft);on('#checkout-form','change',()=>{updateCheckout();rememberDraft();});
on('#checkout-form','submit',async e=>{e.preventDefault();if(!appReady)return;const button=$('#checkout-next');if(button.disabled)return;button.disabled=true;try{await flushDraft();if(checkoutStep<3){setCheckoutStep(checkoutStep+1);return;}const keyName='stride-order-key-'+activeProfile.id;let key=read(keyName,null);if(!key){key=crypto.randomUUID();write(keyName,key);}const id=await cloud.checkout(key,checkoutData());sessionStorage.removeItem(keyName);sessionStorage.removeItem('stride-draft-'+activeProfile.id);go('confirmacion.html?id='+encodeURIComponent(id));}catch(error){$('#checkout-error').textContent=cloud.message(error);$('#checkout-error').scrollIntoView({block:'center',behavior:'smooth'});}finally{button.disabled=false;}});
on('#checkout-back','click',async()=>{try{await flushDraft();checkoutStep>1?setCheckoutStep(checkoutStep-1):go('carrito.html');}catch(error){$('#checkout-error').textContent=cloud.message(error);}});
on('#register-form','submit',async e=>{e.preventDefault();if(!appReady)return;const form=e.target,button=form.querySelector('[type=submit]');if(button.disabled)return;button.disabled=true;$('#register-error').textContent='';try{const email=$('#register-email').value.trim().toLowerCase();const {data,error}=await cloud.db.auth.signUp({email,password:$('#register-password').value,options:{data:{first_name:$('#register-name').value.trim(),last_name:$('#register-lastname').value.trim()},emailRedirectTo:'https://aisaac-bot.github.io/stride-ecommerce/login.html'}});if(error)throw error;form.reset();$('#register-status').textContent='Revisa tu correo y abre el enlace de confirmación. Si ya tienes cuenta, inicia sesión.';if(data.session)finishSession();}catch(error){$('#register-error').textContent=cloud.message(error);}finally{button.disabled=false;}});
on('#account-form','submit',async e=>{e.preventDefault();if(!appReady)return;const button=e.target.querySelector('[type=submit]');if(button.disabled)return;button.disabled=true;$('#account-error').textContent='';try{const {error}=await cloud.db.auth.signInWithPassword({email:$('#account-email').value.trim().toLowerCase(),password:$('#account-password').value});if(error)throw error;e.target.reset();finishSession();}catch(error){$('#account-error').textContent=cloud.message(error);}finally{button.disabled=false;}});
on('#profile-form','submit',async e=>{e.preventDefault();if(!appReady)return;const button=e.target.querySelector('[type=submit]');if(button.disabled)return;button.disabled=true;$('#profile-status').textContent='Guardando…';try{const data={};for(const key of ['name','lastName','cedula','phone','street','crossStreet','house','reference'])data[key]=e.target.elements.namedItem(key).value.trim();data.phone=data.phone.replace(/[\s-]/g,'');await cloud.saveProfile(data);activeProfile=await cloud.profile(activeProfile.id);$('#profile-status').textContent='Tus cambios se han guardado en tu cuenta.';}catch(error){$('#profile-status').textContent=cloud.message(error);}finally{button.disabled=false;}});
on('#profile-logout','click',logout);
const eyeIcon='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>';
$$('[data-password-toggle]').forEach(b=>{b.innerHTML=eyeIcon;b.addEventListener('click',()=>{const f=document.getElementById(b.dataset.passwordToggle),visible=f.type==='password';f.type=visible?'text':'password';b.setAttribute('aria-pressed',String(visible));b.setAttribute('aria-label',(visible?'Ocultar':'Mostrar')+' contraseña');});});
$('#guide-rows').innerHTML=Array.from({length:9},(_,i)=>`<tr><th scope="row">${36+i}</th><td>${(23+i*.65).toFixed(1)} cm</td></tr>`).join('');
for(const [button,dialog] of [['#footer-size-guide','#guide-dialog'],['#help-open','#help-dialog']])on(button,'click',()=>showDialog($(dialog)));
for(const [button,dialog] of [['#guide-close','#guide-dialog'],['#help-close','#help-dialog'],['#product-alert-ok','#product-alert']])on(button,'click',()=>$(dialog).close());
document.addEventListener('click',async e=>{
 const b=e.target.closest('button');if(!b)return;if(b.id==='connection-retry'){location.reload();return;}if(b.id==='catalog-retry'){renderCatalog();return;}if(!appReady)return;
 if(b.dataset.favorite){toggleFavorite(b.dataset.favorite);return;}
 if(b.dataset.category){filters.category=b.dataset.category;renderCatalog();}
 if(b.dataset.filterSize){filters.size=filters.size===Number(b.dataset.filterSize)?null:Number(b.dataset.filterSize);renderCatalog();}
 if(b.dataset.filterColor){filters.color=filters.color===b.dataset.filterColor?null:b.dataset.filterColor;renderCatalog();}
 if(b.dataset.removeFilter){filters[b.dataset.removeFilter]=defaults()[b.dataset.removeFilter];filters.favoritesOnly=page==='favoritos';renderCatalog();}
 if(b.dataset.page){catalogPage=Number(b.dataset.page);renderCatalog();$('#result-count').setAttribute('tabindex','-1');$('#result-count').focus();}
 if(b.dataset.detailSize){selectedSize=Number(b.dataset.detailSize);$$('[data-detail-size]').forEach(el=>el.setAttribute('aria-pressed',String(el===b)));}
 if(b.id==='detail-size-guide')showDialog($('#guide-dialog'));
 if(b.id==='detail-plus'||b.id==='detail-minus'){detailQuantity=Math.min(10,Math.max(1,detailQuantity+(b.id==='detail-plus'?1:-1)));$('#detail-quantity').textContent=detailQuantity;$('#detail-minus').disabled=detailQuantity===1;$('#detail-plus').disabled=detailQuantity===10;}
 if(b.id==='add-cart'){if(!selectedSize){productError('Selecciona una talla para continuar.');return;}if(!requireAccount({type:'cart',id:currentProduct.id,size:selectedSize,quantity:detailQuantity}))return;b.disabled=true;try{cart=await cloud.changeCart(currentProduct.id,selectedSize,detailQuantity,true);updateCartCount();toast('Producto añadido al carrito.');}catch(error){productError(cloud.message(error));}finally{b.disabled=false;}}
 if(b.dataset.productView){const view=productViews(currentProduct)[Number(b.dataset.productView)],img=$('#detail-image-panel img');img.dataset.viewImage=view.image;img.src=optimizedImage(view.image,640);img.alt=currentProduct.name+' · '+view.label;img.classList.toggle('born-image',Number(b.dataset.productView)===0&&currentProduct.id==='born-raised');$$('[data-product-view]').forEach(el=>el.setAttribute('aria-pressed',String(el===b)));$('#detail-image-panel').classList.remove('zoomed');$('#image-zoom').setAttribute('aria-pressed','false');}
 if(b.id==='image-zoom'){const active=b.getAttribute('aria-pressed')!=='true';b.setAttribute('aria-pressed',String(active));b.setAttribute('aria-label',active?'Reducir imagen':'Ampliar imagen');$('#detail-image-panel').classList.toggle('zoomed',active);const img=$('#detail-image-panel img');img.src=optimizedImage(img.dataset.viewImage,active?1024:640);}
 if(b.dataset.cartAction){const item=cart[Number(b.dataset.index)];if(!item||b.disabled)return;b.disabled=true;try{cart=await cloud.changeCart(item.id,item.size,b.dataset.cartAction==='remove'?0:Math.min(10,Math.max(1,item.quantity+(b.dataset.cartAction==='plus'?1:-1))));renderCart();}catch(error){productError(cloud.message(error));b.disabled=false;}}
 if(b.id==='simulate-order')go('checkout.html');if(b.id==='cart-explore')go('catalogo.html');
});
window.addEventListener('pageshow',e=>{if(e.persisted)location.reload();});
if(page==='index'&&location.hash.startsWith('#producto/'))location.replace('producto.html?id='+encodeURIComponent(location.hash.slice(10)));
init();
document.addEventListener('click',async e=>{const a=e.target.closest('a[href]');if(page!=='checkout'||!activeProfile||!a||e.ctrlKey||e.metaKey||a.target==='_blank')return;e.preventDefault();try{await flushDraft();go(a.href);}catch(error){toast(cloud.message(error));}},true);

if(page==='index'){
const cinema=$('#inicio');
const motionQuery=window.matchMedia?.('(prefers-reduced-motion: reduce)');
let reducedMotion=document.documentElement.classList.contains('wireframe')||motionQuery?.matches||false;
let cinemaProgress=0,cinemaIndex=-1,playing=false,lastTick=0,autoFrame=0,cinemaQueued=false;
const duration=14000; // Four scenes, 3.5 seconds each; independent of page scrolling.
function renderCinema(progress){
 const frame=cinematicFrame(progress);cinemaProgress=frame.progress;cinema.dataset.scene=String(frame.index);
 cinema.style.setProperty('--journey',frame.progress);cinema.style.setProperty('--scene-progress',frame.local);
 $('#cinema-phase-line').style.height=`${frame.progress*100}%`;
 if(frame.index!==cinemaIndex){
 cinemaIndex=frame.index;$('#hero-title').innerHTML=`${frame.title}<br><span>${frame.accent}</span>`;$('#cinema-description').innerHTML=frame.description;
 $('#cinema-phase-index').textContent=String(frame.index+1).padStart(2,'0');
 $('#spotlight-word').textContent=frame.word;$('#spotlight-caption').textContent=frame.name+' ↗';
 $('#spotlight-image').src=optimizedImage(frame.image,1024);$('#spotlight-image').alt=frame.alt;$('#spotlight-link').href='producto.html?id='+frame.id;$('#spotlight-link').setAttribute('aria-label','Ver '+frame.name);$('#spotlight-buy').href='producto.html?id='+frame.id;$('#spotlight-buy').innerHTML=frame.cta+' <span aria-hidden="true">↗</span>';
 $$('[data-scene-go]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.sceneGo)===frame.index)));
 }
}
function setPlaying(next){playing=next&&!reducedMotion;lastTick=0;cancelAnimationFrame(autoFrame);$('#cinema-play').textContent=playing?'Pausar Ⅱ':'Reproducir ▷';$('#cinema-play').setAttribute('aria-label',playing?'Pausar presentación':'Reproducir presentación');$('#cinema-play').hidden=reducedMotion;renderCinema(cinemaProgress);if(playing)autoFrame=requestAnimationFrame(tick);}
function tick(now){if(!playing)return;if(document.hidden||$('#storefront').hidden||dialogs.some(d=>d.open)){lastTick=0;autoFrame=requestAnimationFrame(tick);return;}if(!lastTick)lastTick=now;const next=Math.min(1,cinemaProgress+Math.min(now-lastTick,100)/duration);lastTick=now;renderCinema(next);if(next>=1){setPlaying(false);return;}autoFrame=requestAnimationFrame(tick);}
function updateCinema(){const start=cinema.offsetTop;$('#main-header').classList.toggle('over-cinema',window.scrollY<start+cinema.offsetHeight-window.innerHeight*.3);cinemaQueued=false;}
function queueCinema(){if(!cinemaQueued){cinemaQueued=true;requestAnimationFrame(updateCinema);}}
function goScene(progress){setPlaying(false);renderCinema(progress);}
$$('[data-scene-go]').forEach(b=>b.addEventListener('click',()=>goScene([0,.26,.51,.76][Number(b.dataset.sceneGo)])));
$('#cinema-play').addEventListener('click',()=>{if(playing){setPlaying(false);return;}if(cinemaProgress>=.98)renderCinema(0);setPlaying(true);});

window.addEventListener('scroll',queueCinema,{passive:true});window.addEventListener('resize',queueCinema);
motionQuery?.addEventListener('change',e=>{reducedMotion=e.matches||document.documentElement.classList.contains('wireframe');setPlaying(false);});

renderCinema(0);updateCinema();setPlaying(!reducedMotion&&(!location.hash||location.hash==='#inicio')&&window.scrollY<40);


}
