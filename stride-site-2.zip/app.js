import {products,colors,defaults,filterProducts,sanitizeCart,addCartItem,cartTotals} from './catalog.js';
import {cinematicFrame} from './cinema.js';

const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const money=n=>`$${n.toFixed(2)}`;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const drawings={
 'heart':'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
 'bag':'<path d="M5 7h14l1 14H4L5 7Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/>',
 'menu':'<path d="M4 6h16M4 12h16M4 18h16"/>',
 'close':'<path d="m6 6 12 12M18 6 6 18"/>',
 'search':'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
 'arrow-right':'<path d="M4 12h16m-6-6 6 6-6 6"/>',
 'arrow-up-right':'<path d="M6 18 18 6M6 6h12v12"/>',
 'arrow-down':'<path d="M12 4v16m-6-6 6 6 6-6"/>',
 'arrow-up':'<path d="M12 20V4m-6 6 6-6 6 6"/>',
 'sliders':'<path d="M4 6h5m4 0h7M4 12h9m4 0h3M4 18h3m4 0h9"/><circle cx="11" cy="6" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="9" cy="18" r="2"/>',
 'ruler':'<path d="m3 16 13-13 5 5L8 21 3 16Z"/><path d="m13 6 3 3M9 10l2 2m-6 2 3 3"/>',
 'spark':'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z"/>',
 'check':'<path d="m5 12 4 4L19 6"/>',
 'zoom':'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5M10.5 7v7M7 10.5h7"/>'
};
const icon=name=>`<svg viewBox="0 0 24 24" aria-hidden="true">${drawings[name]||drawings['arrow-right']}</svg>`;
function hydrateIcons(root=document){root.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=icon(el.dataset.icon);});}
function read(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}}
function write(key,value){try{localStorage.setItem(key,JSON.stringify(value));}catch{}}
let favorites=read('stride-favorites',[]);
favorites=Array.isArray(favorites)?[...new Set(favorites.filter(id=>products.some(p=>p.id===id)))]:[];
let cart=sanitizeCart(read('stride-cart',[]));
let filters=defaults();
let currentProduct=null,selectedSize=null,detailQuantity=1,toastTimer,lastRemovedItem=null;
const dialogs=[$('#cart-dialog'),$('#guide-dialog'),$('#help-dialog'),$('#reader-dialog'),$('#account-dialog')];
function showDialog(d){if(!d.open)d.showModal();}
function productError(message){clearTimeout(toastTimer);$('#toast').classList.remove('visible');const alert=$('#size-error');alert.textContent=message;alert.setAttribute('tabindex','-1');alert.scrollIntoView({block:'center',behavior:'smooth'});alert.focus({preventScroll:true});}
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),6000);}
function ratingMarkup(p){return `<div class="product-rating" aria-label="Calificación de demostración: ${p.rating} de 5, ${p.reviewCount} reseñas"><span class="rating-stars" aria-hidden="true"><span>★★★★★</span><span class="rating-fill" style="width:${p.rating/5*100}%">★★★★★</span></span><span>${p.rating.toFixed(1).replace('.',',')} (${p.reviewCount})</span><small>Demo</small></div>`;}
function badge(p){return p.badge?`<span class="product-badge${p.oldPrice?' sale':''}">${p.badge}</span>`:'';}

const optimizedImage=(file,width)=>`assets/fast-v2/${file}-${width}.webp`;
const preparedProducts=new Set();
function prepareProductImage(event){
 const link=event.target.closest('a[href^="#producto/"]');if(!link||navigator.connection?.saveData)return;
 const id=link.getAttribute('href').slice('#producto/'.length),product=products.find(p=>p.id===id);
 if(!product||preparedProducts.has(id))return;preparedProducts.add(id);
 const image=new Image();image.fetchPriority='low';image.src=optimizedImage(product.image,640);
}
document.addEventListener('pointerover',prepareProductImage,{passive:true});
document.addEventListener('focusin',prepareProductImage);
function productCard(p,index=0){return `<article class="product-card" data-product="${p.id}">
  <a class="product-image-wrap" href="#producto/${p.id}" aria-label="Ver detalle de ${p.name}" data-placeholder="Imagen de ${p.name}">${badge(p)}<img class="product-image ${p.id==='born-raised'?'born-image':''}" src="${optimizedImage(p.image,320)}" srcset="${optimizedImage(p.image,320)} 320w, ${optimizedImage(p.image,480)} 480w" sizes="(max-width:700px) 50vw, (max-width:1000px) 33vw, 25vw" decoding="async" alt="${p.name}, ${p.category.toLowerCase()} de color ${p.color.toLowerCase()}" width="1024" height="1024" loading="${index<6&&!location.hash.startsWith('#producto/')?'eager':'lazy'}"><span class="product-view">Explorar el par ${icon('arrow-up-right')}</span></a>
  <button class="product-favorite" data-favorite="${p.id}" aria-label="${favorites.includes(p.id)?'Quitar de':'Añadir a'} favoritos: ${p.name}" aria-pressed="${favorites.includes(p.id)}">${icon('heart')}</button>
  <div class="product-info"><div class="product-type"><span>${p.category}</span><span class="product-color"><i style="background:${p.hex}" aria-hidden="true"></i>${p.color}</span></div><div class="product-name-price"><h3><a href="#producto/${p.id}">${p.name}</a></h3><div class="product-price">${p.oldPrice?`<del>$${p.oldPrice}</del>`:''}$${p.price}</div></div>${ratingMarkup(p)}<div class="product-sizes"><span>EU</span>${p.sizes.map(s=>`<span>${s}</span>`).join('')}</div></div>
 </article>`;}

function renderCatalog(){
 const found=filterProducts(filters,favorites);
 $('#product-grid').innerHTML=found.map(productCard).join('');
 $('#result-count').textContent=`${found.length} ${found.length===1?'producto':'productos'}${filters.favoritesOnly?' en favoritos':''}`;
 $('#empty-state').hidden=found.length>0;
 $('#favorites-clear').hidden=!filters.favoritesOnly;
 syncFilters();updateFavoriteUI();
}
function syncFilters(){
 $$('[data-category]').forEach(b=>{const active=b.dataset.category===filters.category;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});
 $$('[data-filter-size]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.filterSize)===filters.size)));
 $$('[data-filter-color]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.filterColor===filters.color)));
 $('#search').value=filters.search;$('#max-price').value=filters.maxPrice;$('#price-value').textContent=`$${filters.maxPrice}`;$('#sale-only').checked=filters.saleOnly;$('#sort').value=filters.sort;
 const chips=[];
 if(filters.category!=='all')chips.push(['category',filters.category]);
 if(filters.search)chips.push(['search',`“${filters.search}”`]);
 if(filters.size)chips.push(['size',`Talla ${filters.size}`]);
 if(filters.color)chips.push(['color',filters.color]);
 if(filters.maxPrice<defaults().maxPrice)chips.push(['maxPrice',`Hasta $${filters.maxPrice}`]);
 if(filters.saleOnly)chips.push(['saleOnly','Ofertas']);
 if(filters.favoritesOnly)chips.push(['favoritesOnly','Favoritos']);
 $('#active-filters').innerHTML=chips.map(([key,label])=>`<button class="filter-chip" data-remove-filter="${key}" aria-label="Quitar filtro: ${esc(label)}">${esc(label)}${icon('close')}</button>`).join('');
 $('#filter-count').textContent=chips.length?String(chips.length):'';
}
function resetFilters(){filters=defaults();renderCatalog();}
function updateFavoriteUI(){
 $('#favorite-count').textContent=favorites.length;$('#favorite-count').hidden=favorites.length===0;
 $('#favorites-toggle').setAttribute('aria-pressed',String(filters.favoritesOnly));
 $('#favorites-toggle').setAttribute('aria-label',filters.favoritesOnly?'Ver toda la colección':'Ver favoritos');
 $$('[data-favorite]').forEach(b=>{
  const active=favorites.includes(b.dataset.favorite);const p=products.find(p=>p.id===b.dataset.favorite);
  b.setAttribute('aria-pressed',String(active));b.setAttribute('aria-label',`${active?'Quitar de':'Añadir a'} favoritos: ${p.name}`);
  const label=b.querySelector('[data-favorite-label]');if(label)label.textContent=active?'Guardado en tus favoritos':'Guardar en favoritos';
 });
}
function toggleFavorite(id){
 if(favorites.includes(id)){favorites=favorites.filter(x=>x!==id);toast('Eliminado de tus favoritos.');}else{favorites.push(id);toast('Guardado en tus favoritos.');}
 write('stride-favorites',favorites);renderCatalog();
}
const bornViews=[{image:'born-raised-original.webp',label:'Original'},{image:'born-lateral.png',label:'Lateral'},{image:'born-superior.png',label:'Superior'}];
function productViews(p){return p.id==='born-raised'?bornViews:[{image:p.image,label:'Original'},{image:p.id+'-posterior.webp',label:'Posterior'},{image:p.id+'-superior.webp',label:'Superior'}];}
function renderProduct(p){
 currentProduct=p;selectedSize=null;detailQuantity=1;
 $('#product-detail').innerHTML=`<div class="detail-layout"><div class="detail-image-panel" id="detail-image-panel">${badge(p)}<img class="${p.id==='born-raised'?'born-image':''}" src="${optimizedImage(p.image,640)}" fetchpriority="high" decoding="async" alt="${p.name} en color ${p.color.toLowerCase()}" width="1024" height="1024"><span class="detail-image-caption">STRIDE SELECTION / ${p.category.toUpperCase()}</span><button class="zoom-button" id="image-zoom" aria-label="Ampliar imagen" aria-pressed="false">${icon('zoom')}</button></div><div class="detail-copy"><p class="detail-category">COLECCIÓN 01 / ${p.category.toUpperCase()}</p><h1 id="detail-title" tabindex="-1">${p.name}</h1>${ratingMarkup(p)}<p class="detail-tagline">${p.tagline}</p><div class="detail-price">${money(p.price)}${p.oldPrice?`<del>${money(p.oldPrice)}</del>`:''}<small>USD</small></div><p class="detail-description">${p.description}</p><p class="detail-color"><i style="background:${p.hex}" aria-hidden="true"></i><strong>Color:</strong> ${p.color}</p><div class="detail-size-head"><span>Selecciona tu talla · EU</span><button class="text-button" id="detail-size-guide">Guía de tallas</button></div><div class="detail-sizes" role="group" aria-label="Talla del producto">${Array.from({length:9},(_,i)=>i+36).map(s=>`<button data-detail-size="${s}" aria-pressed="false" ${p.sizes.includes(s)?'':`disabled aria-label="Talla ${s}, no disponible"`}>${s}</button>`).join('')}</div><p class="size-error" id="size-error" role="alert"></p><div class="detail-buy"><div class="quantity-control" aria-label="Cantidad de pares"><button id="detail-minus" aria-label="Reducir cantidad" disabled>−</button><span id="detail-quantity" aria-live="polite">1</span><button id="detail-plus" aria-label="Aumentar cantidad">+</button></div><button class="button button-red" id="add-cart">Añadir al carrito ${icon('bag')}</button></div><button class="detail-favorite" data-favorite="${p.id}" aria-pressed="${favorites.includes(p.id)}">${icon('heart')}<span data-favorite-label>${favorites.includes(p.id)?'Guardado en tus favoritos':'Guardar en favoritos'}</span></button><p class="fit-note">${p.fit}</p></div></div>`;
 {
  const views=productViews(p);
  const mainImage=$('#detail-image-panel img');mainImage.dataset.viewImage=p.image;
  const warmViews=()=>{const run=()=>{if(currentProduct?.id!==p.id||navigator.connection?.saveData)return;views.slice(1).forEach(view=>{const image=new Image();image.fetchPriority='low';image.src=optimizedImage(view.image,640);});};if(window.requestIdleCallback)window.requestIdleCallback(run,{timeout:1500});else setTimeout(run,500);};
  if(mainImage.complete)warmViews();else mainImage.addEventListener('load',warmViews,{once:true});
  const panel=$('#detail-image-panel'),gallery=document.createElement('div');gallery.className='detail-gallery';panel.before(gallery);gallery.append(panel);
  gallery.insertAdjacentHTML('beforeend',`<div class="gallery-thumbnails" role="group" aria-label="Vistas de ${p.name}">${views.map((view,i)=>`<button type="button" data-product-view="${i}" aria-pressed="${i===0}" aria-label="Ver vista ${view.label.toLowerCase()}"><img src="${optimizedImage(view.image,160)}" width="160" height="160" alt="Miniatura ${view.label.toLowerCase()}" class="${i===0&&p.id==='born-raised'?'gallery-original':''}" loading="lazy" decoding="async"><span>${view.label}</span></button>`).join('')}</div>${p.id==='born-raised'?'<p class="gallery-note">Las vistas lateral y superior son recreaciones generadas con IA para este prototipo.</p>':''}`);
 }
 $('#product-category-label').textContent=p.category;
 const related=products.filter(item=>item.id!==p.id).sort((a,b)=>Number(b.category===p.category)-Number(a.category===p.category)||Math.abs(a.price-p.price)-Math.abs(b.price-p.price)).slice(0,4);
 $('#related-grid').innerHTML=related.map(productCard).join('');
 updateFavoriteUI();
}
function navigatePage(hash){history.pushState(null,'',hash);handleHash();}
function handleHash(){
 const hash=location.hash,page=$('#product-page'),store=$('#storefront'),checkout=$('#checkout-dialog'),order=$('#order-dialog');
 const wasCheckout=!checkout.hidden,wasFull=!page.hidden||wasCheckout||!order.hidden;
 if(hash==='#compra'&&cart.length){
  store.hidden=true;page.hidden=true;order.hidden=true;checkout.hidden=false;
  document.title='Finalizar compra — STRIDE';
  if(!wasCheckout){setCheckoutStep(1);window.scrollTo({top:0,behavior:'instant'});$('#checkout-title').focus({preventScroll:true});}else updateCheckout();return;
 }
 if(wasCheckout)clearCheckoutFields();checkout.hidden=true;
 if(hash==='#pedido'&&$('#order-summary').textContent.trim()){
  store.hidden=true;page.hidden=true;order.hidden=false;document.title='Pedido confirmado — STRIDE';window.scrollTo({top:0,behavior:'instant'});$('#order-title').focus({preventScroll:true});return;
 }
 order.hidden=true;
 if(hash==='#compra'||hash==='#pedido'){history.replaceState(null,'','#catalogo');handleHash();return;}
 if(hash.startsWith('#producto/')){
  const p=products.find(p=>p.id===hash.slice(10));
  if(!p){toast('Ese producto no está en la colección.');history.replaceState(null,'','#catalogo');handleHash();return;}
  if(currentProduct?.id===p.id&&!page.hidden)return;
  renderProduct(p);store.hidden=true;page.hidden=false;document.title=p.name+' — STRIDE';window.scrollTo({top:0,behavior:'instant'});$('#detail-title').focus({preventScroll:true});
 }else{page.hidden=true;store.hidden=false;document.title='STRIDE — Tu ritmo. Tus reglas.';if(wasFull){const target=['#inicio','#catalogo','#esencia'].includes(hash)?$(hash):$('#catalogo');target.scrollIntoView({behavior:'instant',block:'start'});}}
}
function returnToCart(){navigatePage('#catalogo');renderCart();showDialog($('#cart-dialog'));}
function closeProduct(){
 history.replaceState(null,'','#catalogo');handleHash();$('#catalog-title').setAttribute('tabindex','-1');$('#catalog-title').focus({preventScroll:true});
}
function saveCart(){write('stride-cart',cart);updateCartCount();}
function updateCartCount(){const total=cartTotals(cart);$('#cart-count').textContent=total.quantity;$('#cart-count').hidden=total.quantity===0;$('#cart-title-count').textContent=`(${total.quantity})`;}
function renderCart(){
 updateCartCount();
 const notice=lastRemovedItem?`<div class="cart-notice" role="status">${products.find(p=>p.id===lastRemovedItem.id).name} eliminado.</div>`:'';
 if(!cart.length){$('#cart-body').innerHTML=notice+`<div class="cart-empty"><span>${icon('bag')}</span><h3>Tu próximo par te espera</h3><p>Explora la colección y añade tus favoritos.</p><button class="button button-black" id="cart-explore">Explorar colección ${icon('arrow-right')}</button></div>`;$('#cart-footer').innerHTML='';return;}
 $('#cart-body').innerHTML=notice+cart.map((v,i)=>{const p=products.find(p=>p.id===v.id);return `<article class="cart-item"><a class="cart-item-image" href="#producto/${p.id}" data-cart-product><img src="${optimizedImage(p.image,160)}" decoding="async" alt="${p.name}" width="100" height="100"></a><div><div class="cart-item-head"><h3>${p.name}</h3><button data-cart-action="remove" data-index="${i}" aria-label="Eliminar ${p.name}, talla ${v.size}">${icon('close')}</button></div><p>${p.color} · Talla ${v.size} EU</p><div class="cart-item-bottom"><div class="quantity-control"><button data-cart-action="minus" data-index="${i}" aria-label="Reducir cantidad de ${p.name}" ${v.quantity<=1?'disabled':''}>−</button><span>${v.quantity}</span><button data-cart-action="plus" data-index="${i}" aria-label="Aumentar cantidad de ${p.name}" ${v.quantity>=10?'disabled':''}>+</button></div><strong>${money(p.price*v.quantity)}</strong></div></div></article>`;}).join('');
 const totals=cartTotals(cart);
 $('#cart-footer').innerHTML=`<div class="cart-total"><span>Total estimado</span><strong>${money(totals.total)}</strong></div><p class="cart-disclaimer">Precios de referencia en dólares estadounidenses.</p><button class="button button-red" id="simulate-order">Continuar compra ${icon('arrow-right')}</button><p class="cart-footnote">Envíos solo a Quito. El costo se calcula en el siguiente paso. Compra simulada.</p>`;
}
let checkoutStep=1,deliveryStage=0;
const shippingPrices={standard:5,express:9,pickup:0};
const deliveryNames={standard:'Quito · a domicilio estándar',express:'Quito · a domicilio exprés',pickup:'Retiro en Quito'};
function checkoutData(){return {...Object.fromEntries(new FormData($('#checkout-form')).entries()),city:'Quito',phone:$('#contact-phone').value.replace(/[\s-]/g,'')};}
function orderAmounts(){const subtotal=cartTotals(cart).total;const shipping=shippingPrices[$('#delivery-method').value]??5;return {subtotal,shipping,total:subtotal+shipping};}
function amountMarkup(){const t=orderAmounts();return `<div><span>Productos</span><strong>${money(t.subtotal)}</strong></div><div><span>Envío</span><strong>${t.shipping?money(t.shipping):'Gratis'}</strong></div><div class="grand-total"><span>Total · USD</span><strong>${money(t.total)}</strong></div>`;}
function orderLines(){return cart.map(v=>{const p=products.find(p=>p.id===v.id);return `<li><span>${esc(p.name)}<small>Talla EU ${v.size} · ${v.quantity} × ${money(p.price)}</small></span><strong>${money(p.price*v.quantity)}</strong></li>`;}).join('');}
function deliveryMarkup(data){return `<p><strong>${deliveryNames[data.delivery]}</strong><br>${esc(data.recipient||'')}${data.phone?'<br>Celular de contacto: '+esc(data.phone):''}${data.delivery==='pickup'?'<br>STRIDE · Quito · mostrador de demostración':`<br>${esc(data.city||'')} · ${esc(data.street||'')} y ${esc(data.crossStreet||'')}<br>Casa: ${esc(data.house||'')}<br>Referencia: ${esc(data.reference||'')}`}</p><p><strong>Pago:</strong> ${data.payment==='card'?`${data.cardNumber?.replace(/\s/g,'')==='5555555555554444'?'Mastercard':'Visa'} de prueba · termina en ${esc((data.cardNumber||'').replace(/\s/g,'').slice(-4))}`:data.delivery==='pickup'?'Pago al retirar':'Contra entrega'}</p>`;}
function updateCheckout(){
 const data=checkoutData(),pickup=data.delivery==='pickup';
 $('#address-fields').disabled=pickup;$('#address-fields').hidden=pickup;$('#pickup-note').hidden=!pickup;
 $('#delivery-estimate').textContent=pickup?'Retiro disponible en 24 horas (simulado).':data.delivery==='express'?'Entrega en Quito: 1 a 2 días hábiles (simulada).':'Entrega en Quito: 3 a 5 días hábiles (simulada).';
 $('#card-demo').hidden=data.payment!=='card';$('#card-fields').disabled=data.payment!=='card';$('#contact-phone').required=!pickup;$('#cash-note').hidden=data.payment==='card';
 $('#cash-note').textContent=pickup?'Pagarás el total al retirar el pedido en tienda (simulado).':'Pagarás el total al recibir tu pedido. Sin recargo en esta simulación.';
 $('#checkout-totals').innerHTML=amountMarkup();$('#checkout-items').innerHTML=orderLines();
 $('#checkout-review').innerHTML=`<ul class="order-lines">${orderLines()}</ul>${deliveryMarkup(data)}`;
}
function setCheckoutStep(step){
 checkoutStep=step;$$('[data-checkout-step]').forEach(el=>el.hidden=Number(el.dataset.checkoutStep)!==step);
 $$('[data-step-label]').forEach(el=>{if(Number(el.dataset.stepLabel)===step)el.setAttribute('aria-current','step');else el.removeAttribute('aria-current');});
 $('#checkout-back').textContent=step===1?'Volver al carrito':'← Atrás';$('#checkout-next').textContent=step===1?'Continuar al pago →':step===2?'Revisar pedido →':'Confirmar pedido simulado';$('#checkout-error').textContent='';updateCheckout();
 $(`[data-checkout-step="${step}"] h3`).focus();
}
function simulateOrder(){if(!cart.length)return;$('#cart-dialog').close();navigatePage('#compra');}
function completeOrder(){
 const data=checkoutData();if(!cart.length){$('#checkout-error').textContent='Tu carrito está vacío.';return;}
 const summary=`<strong>STR-${Date.now().toString().slice(-6)}</strong><ul class="order-lines">${orderLines()}</ul><div class="checkout-totals">${amountMarkup()}</div>${deliveryMarkup(data)}`;
 $('#order-summary').innerHTML=summary;clearCheckoutFields();$('#checkout-dialog').hidden=true;cart=[];lastRemovedItem=null;saveCart();renderCatalog();deliveryStage=0;$('#delivery-status').textContent='Pedido confirmado · simulación';$('#advance-delivery').hidden=false;$('#advance-delivery').textContent='Simular preparación';$('#advance-delivery').dataset.pickup=String(data.delivery==='pickup');navigatePage('#pedido');$('#checkout-form').reset();
}
$('#checkout-form').addEventListener('change',updateCheckout);
let paymentTimer=null;
function checkoutError(field,message){field.setAttribute('aria-invalid','true');$('#checkout-error').textContent=message;field.focus();return false;}
function validateCard(){
 const holder=$('#card-holder'),number=$('#card-number'),expiry=$('#card-expiry'),cvv=$('#card-cvv');
 if(!holder.value.trim())return checkoutError(holder,'Ingresa el nombre del titular ficticio.');
 if(!['4242424242424242','5555555555554444'].includes(number.value.replace(/\s/g,'')))return checkoutError(number,'Usa una de las dos tarjetas de prueba indicadas. No ingreses datos reales.');
 const match=/^(0[1-9]|1[0-2])\/(\d{2})$/.exec(expiry.value);const now=new Date();
 if(!match||new Date(2000+Number(match[2]),Number(match[1]),1)<=now)return checkoutError(expiry,'Ingresa un vencimiento futuro con formato MM/AA.');
 if(cvv.value!=='123')return checkoutError(cvv,'El CVV de prueba es 123.');
 return true;
}
function clearCheckoutFields(){clearTimeout(paymentTimer);paymentTimer=null;$('#checkout-next').disabled=false;$('#checkout-back').disabled=false;$('#checkout-form').removeAttribute('aria-busy');$('#checkout-form').reset();$$('#checkout-form [aria-invalid]').forEach(el=>el.removeAttribute('aria-invalid'));$('#card-brand').textContent='Marca: introduce una tarjeta de prueba.';}

$('#checkout-form').addEventListener('submit',e=>{
 e.preventDefault();if(paymentTimer)return;
 if(checkoutStep===1){
  const phone=$('#contact-phone');phone.value=phone.value.replace(/[\s-]/g,'');
  if((phone.required||phone.value)&&!/^09\d{8}$/.test(phone.value)){checkoutError(phone,'Ingresa un celular de 10 dígitos que comience con 09.');return;}
  const fields=[...$('[data-checkout-step="1"]').querySelectorAll('input,textarea')].filter(el=>!el.matches(':disabled'));
  for(const field of fields){if(field.required&&!field.value.trim()){checkoutError(field,'Completa '+field.closest('label').firstChild.textContent.trim().toLowerCase()+' para continuar.');return;}field.removeAttribute('aria-invalid');}
 }
 if(checkoutStep===2&&checkoutData().payment==='card'&&!validateCard())return;
 if(checkoutStep<3){setCheckoutStep(checkoutStep+1);return;}
 if(checkoutData().payment==='card'){
  if(!validateCard()){setCheckoutStep(2);validateCard();return;}
  $('#checkout-next').disabled=true;$('#checkout-back').disabled=true;$('#checkout-form').setAttribute('aria-busy','true');$('#checkout-error').textContent='Procesando pago de prueba…';
  paymentTimer=setTimeout(()=>{paymentTimer=null;$('#checkout-next').disabled=false;$('#checkout-back').disabled=false;$('#checkout-form').removeAttribute('aria-busy');if(!$('#checkout-dialog').hidden)completeOrder();},1200);
 }else completeOrder();
});
function updateCardBrand(){const n=$('#card-number').value.replace(/\s/g,'');$('#card-brand').textContent=n==='4242424242424242'?'Visa de prueba':n==='5555555555554444'?'Mastercard de prueba':'Marca: usa una tarjeta de prueba indicada.';}
$('#card-number').addEventListener('input',e=>{e.target.value=e.target.value.replace(/\D/g,'').slice(0,16).replace(/(.{4})/g,'$1 ').trim();updateCardBrand();});
$$('[data-demo-card]').forEach(button=>button.addEventListener('click',()=>{$('#card-holder').value='CLIENTE DEMO';$('#card-number').value=button.dataset.demoCard==='visa'?'4242 4242 4242 4242':'5555 5555 5555 4444';$('#card-expiry').value='12/'+String(Math.max(2030,new Date().getFullYear()+1)).slice(-2);$('#card-cvv').value='123';$$('#card-fields [aria-invalid]').forEach(el=>el.removeAttribute('aria-invalid'));$('#checkout-error').textContent='';updateCardBrand();updateCheckout();}));
$('#checkout-form').addEventListener('input',e=>{if(e.target.setCustomValidity)e.target.setCustomValidity('');e.target.removeAttribute('aria-invalid');});
$('#checkout-back').addEventListener('click',()=>{if(checkoutStep>1)setCheckoutStep(checkoutStep-1);else{returnToCart();}});
$('#checkout-close').addEventListener('click',()=>{returnToCart();});
$('#advance-delivery').addEventListener('click',()=>{deliveryStage++;const pickup=$('#advance-delivery').dataset.pickup==='true';$('#delivery-status').textContent=deliveryStage===1?'En preparación · simulación':pickup?'Retirado en tienda · simulación completada':'Entregado · simulación completada';$('#advance-delivery').textContent=pickup?'Simular retiro':'Simular entrega';if(deliveryStage>=2)$('#advance-delivery').hidden=true;});


$('#size-filter').innerHTML=Array.from({length:9},(_,i)=>i+36).map(s=>`<button data-filter-size="${s}" aria-label="Filtrar por talla ${s}" aria-pressed="false">${s}</button>`).join('');
$('#color-filter').innerHTML=colors.map(c=>`<button data-filter-color="${c.name}" aria-label="Filtrar por color ${c.name}" aria-pressed="false"><span class="swatch" style="background:${c.hex}" aria-hidden="true"></span>${c.name}<span class="color-check" aria-hidden="true">✓</span></button>`).join('');
$('#guide-rows').innerHTML=Array.from({length:9},(_,i)=>`<tr><th scope="row">${i+36}</th><td>${(23+i*.65).toFixed(1)} cm</td></tr>`).join('');
hydrateIcons();renderCatalog();updateCartCount();

document.addEventListener('click',e=>{
 const viewButton=e.target.closest('[data-product-view]');if(viewButton&&currentProduct){
  const index=Number(viewButton.dataset.productView),view=productViews(currentProduct)[index],img=$('#detail-image-panel img');if(!view)return;
  img.dataset.viewImage=view.image;img.src=optimizedImage(view.image,640);img.alt=currentProduct.name+' · Vista '+view.label.toLowerCase();img.classList.toggle('born-image',index===0&&currentProduct.id==='born-raised');
  $$('[data-product-view]').forEach(b=>b.setAttribute('aria-pressed',String(b===viewButton)));
  $('#detail-image-panel').classList.remove('zoomed');$('#image-zoom').setAttribute('aria-pressed','false');$('#image-zoom').setAttribute('aria-label','Ampliar imagen');return;
 }
 const favorite=e.target.closest('[data-favorite]');if(favorite){toggleFavorite(favorite.dataset.favorite);return;}
 const category=e.target.closest('[data-category]');if(category){filters.category=category.dataset.category;renderCatalog();return;}
 const size=e.target.closest('[data-filter-size]');if(size){const n=Number(size.dataset.filterSize);filters.size=filters.size===n?null:n;renderCatalog();return;}
 const color=e.target.closest('[data-filter-color]');if(color){filters.color=filters.color===color.dataset.filterColor?null:color.dataset.filterColor;renderCatalog();return;}
 const chip=e.target.closest('[data-remove-filter]');if(chip){const key=chip.dataset.removeFilter;filters[key]=defaults()[key];renderCatalog();return;}
 const detailSize=e.target.closest('[data-detail-size]');if(detailSize&&!detailSize.disabled){selectedSize=Number(detailSize.dataset.detailSize);$$('[data-detail-size]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.detailSize)===selectedSize)));$('#size-error').textContent='';return;}
 const action=e.target.closest('[data-cart-action]');if(action&&!action.disabled){const i=Number(action.dataset.index);if(!cart[i])return;if(action.dataset.cartAction==='remove'){lastRemovedItem={...cart[i]};cart.splice(i,1);}else cart[i].quantity=Math.min(10,Math.max(1,cart[i].quantity+(action.dataset.cartAction==='plus'?1:-1)));saveCart();renderCart();const focus=$('#simulate-order')||$('#cart-explore');if(focus)focus.focus();return;}
 if(e.target.closest('[data-cart-product]'))$('#cart-dialog').close();
 if(e.target.closest('#detail-size-guide')||e.target.closest('#footer-size-guide'))showDialog($('#guide-dialog'));
 if(e.target.closest('#image-zoom')){const b=$('#image-zoom');const active=b.getAttribute('aria-pressed')!=='true';b.setAttribute('aria-pressed',String(active));b.setAttribute('aria-label',active?'Reducir imagen':'Ampliar imagen');$('#detail-image-panel').classList.toggle('zoomed',active);if(active){const image=$('#detail-image-panel img');image.src=optimizedImage(image.dataset.viewImage,1024);}}
 if(e.target.closest('#detail-plus')||e.target.closest('#detail-minus')){detailQuantity=Math.min(10,Math.max(1,detailQuantity+(e.target.closest('#detail-plus')?1:-1)));$('#detail-quantity').textContent=detailQuantity;$('#detail-minus').disabled=detailQuantity===1;$('#detail-plus').disabled=detailQuantity===10;}
 if(e.target.closest('#add-cart')){
  if(!selectedSize){productError('Selecciona una talla para continuar.');return;}
  try{cart=addCartItem(cart,currentProduct.id,selectedSize,detailQuantity);saveCart();toast(`${currentProduct.name} · EU ${selectedSize} añadido al carrito.`);$('#add-cart').textContent='¡Añadido al carrito!';setTimeout(()=>{if($('#add-cart'))$('#add-cart').innerHTML=`Añadir al carrito ${icon('bag')}`;},1800);}catch(error){productError(error.message+' Revisa la cantidad que ya tienes en el carrito para esta talla.');}
 }
 if(e.target.closest('#cart-explore')){$('#cart-dialog').close();location.hash='catalogo';}
 if(e.target.closest('#simulate-order'))simulateOrder();
});
$('#search').addEventListener('input',e=>{filters.search=e.target.value;renderCatalog();});
$('#max-price').addEventListener('input',e=>{filters.maxPrice=Number(e.target.value);renderCatalog();});
$('#sale-only').addEventListener('change',e=>{filters.saleOnly=e.target.checked;renderCatalog();});
$('#sort').addEventListener('change',e=>{filters.sort=e.target.value;renderCatalog();});
$('#clear-filters').addEventListener('click',resetFilters);$('#empty-clear').addEventListener('click',resetFilters);
$('#favorites-toggle').addEventListener('click',()=>{const next=!filters.favoritesOnly;filters=defaults();filters.favoritesOnly=next;renderCatalog();location.hash='catalogo';});
$('#favorites-clear').addEventListener('click',resetFilters);
$('#filter-toggle').addEventListener('click',()=>{const open=$('#filter-toggle').getAttribute('aria-expanded')!=='true';$('#filter-toggle').setAttribute('aria-expanded',String(open));$('#filter-panel').classList.toggle('is-open',open);});
$('#menu-toggle').addEventListener('click',()=>{const open=$('#menu-toggle').getAttribute('aria-expanded')!=='true';$('#menu-toggle').setAttribute('aria-expanded',String(open));$('#menu-toggle').setAttribute('aria-label',open?'Cerrar menú':'Abrir menú');$('#mobile-menu').hidden=!open;});
$('#mobile-menu').addEventListener('click',e=>{if(e.target.closest('a')){$('#mobile-menu').hidden=true;$('#menu-toggle').setAttribute('aria-expanded','false');$('#menu-toggle').setAttribute('aria-label','Abrir menú');}});
$('#product-close').addEventListener('click',closeProduct);

$('#cart-open').addEventListener('click',()=>{renderCart();showDialog($('#cart-dialog'));});
$('#cart-close').addEventListener('click',()=>$('#cart-dialog').close());
$('#guide-close').addEventListener('click',()=>$('#guide-dialog').close());
$('#order-close').addEventListener('click',()=>{navigatePage('#catalogo');});
$('#help-open').addEventListener('click',()=>showDialog($('#help-dialog')));
$('#help-close').addEventListener('click',()=>$('#help-dialog').close());
dialogs.forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom){d.close();}}}));
window.addEventListener('hashchange',handleHash);handleHash();
if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting)$$('.nav-link').forEach(a=>a.classList.toggle('active',a.getAttribute('href')===`#${entry.target.id}`));});},{rootMargin:'-15% 0px -65% 0px'});['inicio','catalogo','esencia'].forEach(id=>observer.observe(document.getElementById(id)));}

const cinema=$('#inicio');
const motionQuery=window.matchMedia?.('(prefers-reduced-motion: reduce)');
let reducedMotion=document.documentElement.classList.contains('wireframe')||motionQuery?.matches||false;
let cinemaProgress=0,cinemaIndex=-1,playing=false,lastTick=0,autoFrame=0,cinemaQueued=false;
const duration=14000; // Four scenes, 3.5 seconds each; independent of page scrolling.
function renderCinema(progress){
 const frame=cinematicFrame(progress);cinemaProgress=frame.progress;cinema.dataset.scene=String(frame.index);
 cinema.style.setProperty('--journey',frame.progress);cinema.style.setProperty('--scene-progress',frame.local);
 $('#cinema-phase-line').style.height=`${frame.progress*100}%`;
 if(frame.index!==cinemaIndex){
 cinemaIndex=frame.index;$('#hero-title').innerHTML=`${frame.title}<br><span>${frame.accent}</span>`;$('#cinema-description').innerHTML=frame.description;
 $('#cinema-phase-index').textContent=String(frame.index+1).padStart(2,'0');$('#cinema-product-name').textContent=frame.name;$('#cinema-product-tagline').textContent=frame.tagline;
 $('#spotlight-word').textContent=frame.word;$('#spotlight-caption').textContent=frame.name+' ↗';
 $('#spotlight-image').src=optimizedImage(frame.image,1024);$('#spotlight-image').alt=frame.alt;$('#spotlight-link').href='#producto/'+frame.id;$('#spotlight-link').setAttribute('aria-label','Ver '+frame.name);$('#spotlight-buy').href='#producto/'+frame.id;$('#spotlight-buy').innerHTML=frame.cta+' <span aria-hidden="true">↗</span>';
 $$('[data-scene-go]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.sceneGo)===frame.index)));
 }
 $('#cinema-status').textContent=playing?'PRESENTACIÓN / 14 SEG':'EXPLORA A TU RITMO';
}
function setPlaying(next){playing=next&&!reducedMotion;lastTick=0;cancelAnimationFrame(autoFrame);$('#cinema-play').textContent=playing?'Pausar Ⅱ':'Reproducir ▷';$('#cinema-play').setAttribute('aria-label',playing?'Pausar presentación':'Reproducir presentación');$('#cinema-play').hidden=reducedMotion;renderCinema(cinemaProgress);if(playing)autoFrame=requestAnimationFrame(tick);}
function tick(now){if(!playing)return;if(document.hidden||$('#storefront').hidden||dialogs.some(d=>d.open)){lastTick=0;autoFrame=requestAnimationFrame(tick);return;}if(!lastTick)lastTick=now;const next=Math.min(1,cinemaProgress+Math.min(now-lastTick,100)/duration);lastTick=now;renderCinema(next);if(next>=1){setPlaying(false);return;}autoFrame=requestAnimationFrame(tick);}
function updateCinema(){const start=cinema.offsetTop;$('#main-header').classList.toggle('over-cinema',window.scrollY<start+cinema.offsetHeight-window.innerHeight*.3);cinemaQueued=false;}
function queueCinema(){if(!cinemaQueued){cinemaQueued=true;requestAnimationFrame(updateCinema);}}
function goScene(progress){setPlaying(false);renderCinema(progress);}
$$('[data-scene-go]').forEach(b=>b.addEventListener('click',()=>goScene([0,.26,.51,.76][Number(b.dataset.sceneGo)])));
$('#cinema-play').addEventListener('click',()=>{if(playing){setPlaying(false);return;}if(cinemaProgress>=.98)renderCinema(0);setPlaying(true);});
$('#cinema-skip').addEventListener('click',e=>{e.preventDefault();setPlaying(false);history.replaceState(null,'','#catalogo');$('#catalogo').scrollIntoView({behavior:reducedMotion?'instant':'smooth',block:'start'});});
window.addEventListener('scroll',queueCinema,{passive:true});window.addEventListener('resize',queueCinema);
motionQuery?.addEventListener('change',e=>{reducedMotion=e.matches||document.documentElement.classList.contains('wireframe');setPlaying(false);});

renderCinema(0);updateCinema();setPlaying(!reducedMotion&&(!location.hash||location.hash==='#inicio')&&window.scrollY<40);

// Demonstration account: in-memory state only, not authentication or persistent storage.
let demoSignedIn=false,accountMode="login";
function renderAccount(){
 $('#account-credentials').hidden=demoSignedIn||accountMode!=='login';$('#account-registration').hidden=demoSignedIn||accountMode!=='register';$('#account-modes').hidden=demoSignedIn;$('#account-profile').hidden=!demoSignedIn;$('#account-login-mode').setAttribute('aria-pressed',String(accountMode==='login'));$('#account-register-mode').setAttribute('aria-pressed',String(accountMode==='register'));
 $('#account-title').textContent=demoSignedIn?'Mi cuenta de prueba':accountMode==='register'?'Crear cuenta':'Iniciar sesión';
 $$('[data-account-open]').forEach(b=>b.textContent=demoSignedIn?'Mi cuenta':'Iniciar sesión');
}
$$('[data-account-open]').forEach(b=>b.addEventListener('click',()=>{renderAccount();showDialog($('#account-dialog'));}));
$('#account-close').addEventListener('click',()=>$('#account-dialog').close());
$('#account-fill').addEventListener('click',()=>{$('#account-email').value='demo@stride.example';$('#account-password').value='StrideDemo123';$('#account-error').textContent='';});
$('#account-form').addEventListener('submit',e=>{e.preventDefault();if($('#account-email').value.trim().toLowerCase()!=='demo@stride.example'||$('#account-password').value!=='StrideDemo123'){$('#account-error').textContent='Usa el correo y la contraseña de prueba indicados.';$('#account-email').focus();return;}demoSignedIn=true;$('#account-form').reset();$('#account-profile p').textContent='¡Hola, Cliente Demo! Tu sesión de demostración está activa.';renderAccount();$('#account-logout').focus();});
$('#account-logout').addEventListener('click',()=>{demoSignedIn=false;accountMode='login';renderAccount();$('#account-email').focus();});
$('#account-dialog').addEventListener('close',()=>{$('#account-form').reset();$('#register-form').reset();$('#account-error').textContent='';$('#register-error').textContent='';accountMode='login';});

function changeAccountMode(mode){accountMode=mode;$('#account-form').reset();$('#register-form').reset();$('#account-error').textContent='';$('#register-error').textContent='';renderAccount();$(mode==='register'?'#register-name':'#account-email').focus();}
$('#account-login-mode').addEventListener('click',()=>changeAccountMode('login'));
$('#account-register-mode').addEventListener('click',()=>changeAccountMode('register'));
$('#register-fill').addEventListener('click',()=>{$('#register-name').value='Cliente Demo';$('#register-email').value='demo@stride.example';$('#register-password').value='StrideDemo123';$('#register-confirm').value='StrideDemo123';$('#register-error').textContent='';});
$('#register-form').addEventListener('submit',e=>{e.preventDefault();const fields=['#register-name','#register-email','#register-password','#register-confirm'];const fail=(selector,message)=>{$('#register-error').textContent=message;$(selector).focus();};for(const selector of fields){if(!$(selector).value.trim()){fail(selector,'Completa todos los campos con los datos de prueba.');return;}}
 if(!$('#register-email').checkValidity()){fail('#register-email','Ingresa un correo con formato válido.');return;}
 if($('#register-password').value!==$('#register-confirm').value){fail('#register-confirm','Las contraseñas no coinciden.');return;}
 if($('#register-name').value.trim()!=='Cliente Demo'||$('#register-email').value.trim().toLowerCase()!=='demo@stride.example'||$('#register-password').value!=='StrideDemo123'){fail('#register-name','Usa únicamente los datos ficticios indicados o el botón Completar datos de prueba.');return;}
 demoSignedIn=true;$('#register-form').reset();$('#register-error').textContent='';renderAccount();$('#account-profile p').textContent='¡Cuenta de prueba creada! Hola, Cliente Demo. Tu sesión está activa hasta recargar la página.';$('#account-logout').focus();});
