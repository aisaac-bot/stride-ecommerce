const profile=JSON.parse(sessionStorage.getItem('stride-profile')||'null');
if(!profile){location.replace('index.html');}else{
 const form=document.querySelector('#profile-form');
 for(const [key,value] of Object.entries(profile)){if(form.elements[key])form.elements[key].value=value;}
 form.addEventListener('submit',e=>{e.preventDefault();if(!form.reportValidity())return;for(const key of ['name','lastName','phone','street','crossStreet','house','reference']){profile[key]=form.elements[key].value.trim();}sessionStorage.setItem('stride-profile',JSON.stringify(profile));document.querySelector('#profile-status').textContent='Tus cambios se han guardado.';});
 document.querySelector('#profile-logout').addEventListener('click',()=>{sessionStorage.removeItem('stride-profile');location.replace('index.html');});
}
