const $=s=>document.querySelector(s),panel=$('#reader-dialog'),synth=window.speechSynthesis;
let reading=false,paused=false,generation=0,context=null,highlight=null;
const supported=!!synth&&'SpeechSynthesisUtterance' in window;
function status(t){$('#reader-status').textContent=t;}
function stop(){generation++;reading=false;paused=false;if(supported)synth.cancel();$('#reader-pause').textContent='Pausar';if(highlight){highlight.classList.remove('reader-highlight');highlight=null;}}
function visible(el){return el.getClientRects().length>0&&!el.closest('[hidden],[aria-hidden="true"],script,style');}
function textOf(root){
 const result=[];
 function visit(el){if(el.nodeType===3){const t=el.textContent.trim();if(t)result.push(t);return;}if(el.nodeType!==1||!visible(el)||el===panel||el.matches('.dialog-listen,.reader-toggle,.count'))return;
 if(el.tagName==='IMG'){if(el.alt)result.push(el.alt);return;}if(el.matches('input,textarea')){if(el.type==='password'){result.push('Campo oculto');return;}if(el.type==='radio'||el.type==='checkbox'){result.push(el.checked?'Seleccionado':'No seleccionado');}else if(el.value)result.push(el.value);return;}
 if(el.tagName==='SELECT'){result.push(el.selectedOptions[0]?.textContent||'');return;}if(el.matches('button,a')&&el.getAttribute('aria-label')){result.push(el.getAttribute('aria-label'));return;}
 for(const child of el.childNodes)visit(child);
 }visit(root);return result.join(' ').replace(/\s+/g,' ').trim();
}
function speak(text){
 stop();if(!supported){status('Este navegador no ofrece voz. Puedes usar tu lector de pantalla habitual.');return;}if(!text){status('No hay contenido disponible en esta sección.');return;}
 const token=generation,words=text.split(/\s+/),chunks=[];let chunk='';for(const word of words){if((chunk+' '+word).length>180){chunks.push(chunk);chunk='';}chunk+=(chunk?' ':'')+word;}if(chunk)chunks.push(chunk);let index=0;reading=true;
 function next(){if(token!==generation)return;if(index>=chunks.length){reading=false;status('Lectura finalizada.');return;}const u=new SpeechSynthesisUtterance(chunks[index++]);u.lang='es-EC';u.rate=Number($('#reader-rate').value);const voices=synth.getVoices();u.voice=voices.find(v=>v.lang.startsWith('es'))||null;u.onend=next;u.onerror=e=>{if(token!==generation)return;reading=false;status(e.error==='not-allowed'?'Pulsa Leer para permitir la voz del navegador.':'No se pudo reproducir la voz. Intenta de nuevo o usa tu lector habitual.');};synth.speak(u);}status('Leyendo. Puedes pausar o detener.');next();
}
function openReader(){context=[...document.querySelectorAll('dialog[open]')].filter(d=>d!==panel).at(-1)||document.querySelector('main:not([hidden])');$('#reader-section').value='current';if(!panel.open)panel.showModal();}
$('#reader-open').addEventListener('click',openReader);$('#reader-close').addEventListener('click',()=>panel.close());
for(const dialog of document.querySelectorAll('dialog:not(#reader-dialog)')){const btn=document.createElement('button');btn.type='button';btn.className='dialog-listen';btn.textContent='Escuchar esta ventana';btn.addEventListener('click',openReader);dialog.prepend(btn);const stopBtn=document.createElement('button');stopBtn.type='button';stopBtn.className='dialog-listen';stopBtn.textContent='Detener lectura';stopBtn.addEventListener('click',()=>{stop();status('Lectura detenida.');});btn.after(stopBtn);}
$('#reader-start').addEventListener('click',()=>{const id=$('#reader-section').value;let target=id==='current'?(context?.isConnected?context:document.querySelector('main:not([hidden])')):id==='all'?document.body:document.getElementById(id);speak(textOf(target));});
$('#reader-stop').addEventListener('click',()=>{stop();status('Lectura detenida.');});
$('#reader-pause').addEventListener('click',()=>{if(!supported||!reading)return;paused=!paused;if(paused)synth.pause();else synth.resume();$('#reader-pause').textContent=paused?'Reanudar':'Pausar';status(paused?'Lectura en pausa.':'Leyendo.');});
$('#reader-focus').addEventListener('change',()=>{stop();status($('#reader-focus').checked?'Activado. Cierra esta ventana y recorre los controles con Tab.':'Lectura de controles desactivada.');});
document.addEventListener('focusin',e=>{if(!$('#reader-focus').checked||panel.contains(e.target)||!e.target.matches('a,button,input,select,textarea,summary'))return;const el=e.target,label=el.getAttribute('aria-label')||el.labels?.[0]?.textContent||el.textContent||el.getAttribute('placeholder');const value=el.matches('select')?el.selectedOptions[0]?.textContent:el.matches('input:not([type=checkbox]):not([type=radio]):not([type=password]),textarea')?el.value:'';speak([label,value,el.required?'Obligatorio':'',el.getAttribute('aria-pressed')==='true'?'Seleccionado':''].filter(Boolean).join('. '));highlight=el;highlight.classList.add('reader-highlight');});
window.addEventListener('pagehide',stop);if(!supported){$('#reader-start').disabled=true;$('#reader-pause').disabled=true;$('#reader-focus').disabled=true;status('Voz no disponible en este navegador. La página conserva etiquetas y navegación para lectores de pantalla.');}
