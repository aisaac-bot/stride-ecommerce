import * as cloud from './cloud.js?v=20261107-22';
const $=s=>document.querySelector(s), base='https://aisaac-bot.github.io/stride-ecommerce/';
const email=field=>$(field).value.trim().toLowerCase();
function bind(id,status,task){const f=$(id);if(!f)return;f.addEventListener('submit',async e=>{e.preventDefault();const b=f.querySelector('[type=submit]');if(b.disabled)return;b.disabled=true;$(status).textContent='Procesando…';try{await task(f);}catch(err){$(status).textContent=cloud.message(err);}finally{f.querySelectorAll('input[type=password]').forEach(i=>i.value='');b.disabled=false;}});}
async function checked(promise){const r=await promise;if(r.error)throw r.error;return r.data;}
async function reauthenticate(password){const {user}=await checked(cloud.db.auth.getUser());if(!user)throw {code:'P0001',message:'Inicia sesión para continuar.'};await checked(cloud.db.auth.signInWithPassword({email:user.email,password}));return user;}
bind('#email-change-form','#email-change-status',async f=>{
 const u=await reauthenticate($('#email-current-password').value), next=email('#new-email');
 if(next===u.email.toLowerCase())throw {code:'P0001',message:'Ingresa un correo diferente al actual.'};
 await checked(cloud.db.auth.updateUser({email:next},{emailRedirectTo:base+'perfil.html'}));
 f.reset();$('#email-change-status').textContent='Solicitud enviada. Revisa tu correo actual y el nuevo y abre los enlaces de confirmación. Tu correo cambiará cuando completes la verificación.';
});
bind('#password-change-form','#password-change-status',async f=>{
 const next=$('#new-password').value;await reauthenticate($('#current-password').value);
 await checked(cloud.db.auth.updateUser({password:next}));f.reset();$('#password-change-status').textContent='Tu contraseña se ha actualizado. Utiliza la nueva contraseña la próxima vez que inicies sesión.';
});
bind('#recovery-request-form','#recovery-request-status',async()=>{
 await checked(cloud.db.auth.resetPasswordForEmail(email('#recovery-email'),{redirectTo:base+'recuperar.html'}));
 $('#recovery-request-status').textContent='Si este correo tiene una cuenta, recibirás un enlace para restablecer la contraseña. Revisa también spam.';
});
bind('#reset-password-form','#reset-password-status',async f=>{
 const {user}=await checked(cloud.db.auth.getUser());
 if(!user||!(cloud.recoveryUserId===user.id||sessionStorage.getItem('stride-recovery-user')===user.id))throw {code:'P0001',message:'Solicita un enlace nuevo para cambiar tu contraseña.'};
 await checked(cloud.db.auth.updateUser({password:$('#reset-password').value}));
 sessionStorage.removeItem('stride-recovery-user');f.reset();f.hidden=true;
 $('#recovery-help').textContent='Contraseña actualizada. Ya puedes iniciar sesión con tu nueva contraseña.';
 await cloud.db.auth.signOut({scope:'local'});
});
if($('#recovery-help'))(async()=>{
 try{const u=await cloud.user();const error=new URLSearchParams(location.hash.slice(1)).get('error');
 if(error){history.replaceState(null,'',location.pathname);$('#recovery-help').textContent='El enlace no es válido o ha caducado. Solicita uno nuevo.';return;}
 if(u&&(cloud.recoveryUserId===u.id||sessionStorage.getItem('stride-recovery-user')===u.id)){
  $('#recovery-request-form').hidden=true;$('#reset-password-form').hidden=false;$('#recovery-help').textContent='Elige una nueva contraseña para tu cuenta.';
 }
 }catch(e){$('#recovery-help').textContent=cloud.message(e);}
})();
if($('#register-followup')){
 const correct=()=>{sessionStorage.removeItem('stride-unconfirmed-email');$('#register-status').textContent='';$('#confirmation-notice').hidden=true;$('#register-followup').hidden=true;$('#register-help').textContent='Escribe el correo correcto y vuelve a completar el registro. La solicitud anterior seguirá sin confirmar; no modifica una cuenta ya activada.';$('#register-email').value='';$('#register-email').focus();};
 $('#correct-email').addEventListener('click',correct);
 if(new URLSearchParams(location.search).has('corregir'))correct();
 $('#resend-confirmation').addEventListener('click',async e=>{
  const b=e.currentTarget;if(b.disabled)return;b.disabled=true;
  try{const saved=JSON.parse(sessionStorage.getItem('stride-unconfirmed-email')||'null');if(!saved)throw {code:'P0001',message:'Completa el registro con el correo correcto.'};await checked(cloud.db.auth.resend({type:'signup',email:saved,options:{emailRedirectTo:base+'login.html'}}));$('#resend-status').textContent='Si la cuenta está pendiente, recibirás un nuevo enlace. Revisa también spam.';}catch(err){$('#resend-status').textContent=cloud.message(err);}finally{b.disabled=false;}
 });
}
